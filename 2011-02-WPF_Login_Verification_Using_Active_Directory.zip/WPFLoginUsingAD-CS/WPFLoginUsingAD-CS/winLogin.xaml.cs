﻿using System;
using System.Windows;

namespace WPFLoginUsingAD_CS
{
  public partial class winLogin : Window
  {
    public winLogin()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtDomain.Text = Environment.UserDomainName.ToLower();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = false;
    }

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      ADHelper ad = new ADHelper();

      if (ad.AuthenticateUser(txtDomain.Text,
            txtUserName.Text, txtPassword.Password))
        DialogResult = true;
      else
        MessageBox.Show("Unable to Authenticate Using the Supplied Credentials");
    }
  }
}
