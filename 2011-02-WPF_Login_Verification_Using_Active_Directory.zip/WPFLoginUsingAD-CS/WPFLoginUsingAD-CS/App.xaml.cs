﻿using System.Windows;

namespace WPFLoginUsingAD_CS
{
  public partial class App : Application
  {
  }
}
