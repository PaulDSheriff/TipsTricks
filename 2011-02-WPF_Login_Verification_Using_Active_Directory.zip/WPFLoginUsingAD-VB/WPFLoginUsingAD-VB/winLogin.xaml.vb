﻿Partial Public Class winLogin
  Inherits Window

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    txtDomain.Text = Environment.UserDomainName.ToLower()
  End Sub

  Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    DialogResult = False
  End Sub

  Private Sub btnLogin_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim ad As New ADHelper()

    If ad.AuthenticateUser(txtDomain.Text, txtUserName.Text, txtPassword.Password) Then
      DialogResult = True
    Else
      MessageBox.Show("Unable to Authenticate Using the Supplied Credentials")
    End If
  End Sub
End Class