﻿Imports System.DirectoryServices

Public Class ADHelper
#Region "AuthenticateUser Method"
  ''' <summary>
  ''' Authenticates user name and password on the specified domain
  ''' </summary>
  ''' <param name="domainName">Domain Name</param>
  ''' <param name="userName">User Name</param>
  ''' <param name="password">User Password</param>
  ''' <returns>True if user name and password are valid on domain</returns>
  Public Function AuthenticateUser(ByVal domainName As String, ByVal userName As String, ByVal password As String) As Boolean
    Dim ret As Boolean = False

    Try
      Dim de As New DirectoryEntry("LDAP://" & domainName, userName, password)
      Dim dsearch As New DirectorySearcher(de)
      Dim results As SearchResult = Nothing

      results = dsearch.FindOne()

      ret = True
    Catch
      ret = False
    End Try

    Return ret
  End Function
#End Region
End Class