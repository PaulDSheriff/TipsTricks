﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SL_MVVM_Easy.Web
{
  public class Products : List<Product>
  {
  }
}
