﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SL_MVVM_Easy.Web
{
  public class ProductService : IProductService
  {
    public Products GetProducts()
    {
      Products ret = new Products();
      string sql = string.Empty;
      SqlDataAdapter da = null;
      DataTable dt = new DataTable();

      sql = "SELECT ProductName ";
      sql += " FROM Product ";

      // Create Data Adapter
      da = new SqlDataAdapter(sql,
        ConfigurationManager.
             ConnectionStrings["ConnectString"].
               ConnectionString);
      // Fill DataTable with Products
      da.Fill(dt);

      // Loop thru all rows
      // Create a new Product object each time thru
      foreach (DataRow dr in dt.Rows)
      {
        Product prod = new Product();

        prod.ProductName =
          Convert.ToString(dr["ProductName"]);

        ret.Add(prod);
      }

      // Return collection of Product objects
      return ret;
    }
  }
}
