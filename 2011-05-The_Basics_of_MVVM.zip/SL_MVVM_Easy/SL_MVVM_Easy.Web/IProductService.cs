﻿using System.ServiceModel;

namespace SL_MVVM_Easy.Web
{
  [ServiceContract]
  public interface IProductService
  {
    [OperationContract]
    Products GetProducts();
  }
}
