﻿using System;

using System.Runtime.Serialization;

namespace SL_MVVM_Easy.Web
{
  [DataContract]
  public class Product
  {
    [DataMember]
    public string ProductName { get; set; }
  }
}
