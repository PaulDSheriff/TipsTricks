﻿using System.Windows;
using System.Windows.Controls;

namespace SL_MVVM_Easy
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnNoMVVM_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucNoMVVM());
    }

    private void btnMVVM_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucMVVM());
    }
  }
}
