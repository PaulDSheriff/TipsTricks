﻿using System;
using System.Windows;
using System.Windows.Controls;

using SL_MVVM_Easy.ProductServiceReference;

namespace SL_MVVM_Easy
{
  public partial class ucNoMVVM : UserControl
  {
    public ucNoMVVM()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ProductServiceClient client = new ProductServiceClient();

      client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
      client.GetProductsAsync();
      client.CloseAsync();
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      lstData.DataContext = e.Result;
    }
  }
}
