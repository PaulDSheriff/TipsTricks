﻿using System.Windows.Controls;

namespace SL_MVVM_Easy
{
  public partial class ucMVVM : UserControl
  {
    ProductViewModel _ViewModel;

    public ucMVVM()
    {
      InitializeComponent();

      _ViewModel = (ProductViewModel)this.Resources["viewModel"];
    }

    private void UserControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
    {
      _ViewModel.LoadAll();
    }
  }
}
