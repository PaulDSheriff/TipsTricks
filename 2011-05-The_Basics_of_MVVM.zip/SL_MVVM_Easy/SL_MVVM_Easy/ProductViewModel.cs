﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using SL_MVVM_Easy.ProductServiceReference;

namespace SL_MVVM_Easy
{
public class ProductViewModel : INotifyPropertyChanged
{
  #region INotifyPropertyChanged
  /// <summary>
  /// The PropertyChanged Event to raise to any UI object
  /// </summary>
  public event PropertyChangedEventHandler PropertyChanged;

  /// <summary>
  /// The PropertyChanged Event to raise to any UI object
  /// The event is only invoked if data binding is used
  /// </summary>
  /// <param name="propertyName">The property name that is changing</param>
  protected void RaisePropertyChanged(string propertyName)
  {
    PropertyChangedEventHandler handler = this.PropertyChanged;
    if (handler != null)
    {
      PropertyChangedEventArgs args = new PropertyChangedEventArgs(propertyName);

      // Raise the PropertyChanged event.
      handler(this, args);
    }
  }
  #endregion

  private ObservableCollection<Product> _DataCollection;

  public ObservableCollection<Product> DataCollection
  {
    get { return _DataCollection; }
    set
    {
      _DataCollection = value;
      RaisePropertyChanged("DataCollection");
    }
  }

  #region LoadAll Method
  public void LoadAll()
  {
    ProductServiceClient client = new ProductServiceClient();

    client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
    client.GetProductsAsync();
    client.CloseAsync();
  }

  void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
  {
    DataCollection = e.Result;
  }
  #endregion
}
}
