﻿using System.Windows;

namespace WPF_Tile
{
  public partial class App : Application
  {
  }
}
