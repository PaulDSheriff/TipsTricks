﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Collections
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void btnCollectionBase_Click(object sender, RoutedEventArgs e)
		{
			CustCollection();
		}

		private void CustCollection()
		{
			Customer cust;
			Customers custColl = new Customers();
			StringBuilder sb = new StringBuilder();

			cust = new Customer();
			cust.CustomerName = "Microsoft Corporation";
			custColl.Add(cust);

			cust = new Customer();
			cust.CustomerName = "PDSA, Inc.";
			custColl.Add(cust);

			sb.Append("Count = " + custColl.Count.ToString());
			sb.Append(Environment.NewLine);

			foreach (Customer c in custColl)
				sb.Append(c.CustomerName + Environment.NewLine);

			lblMsg.Content = sb.ToString();

			custColl.RemoveAt(0);

			lblMsg.Content += "After the removal = " + custColl.Count;
		}

		private void btnGenericCollection_Click(object sender, RoutedEventArgs e)
		{
			Cust2Collection();
		}

		private void Cust2Collection()
		{
			Customer cust;
			Customers2 custColl = new Customers2();
			StringBuilder sb = new StringBuilder();

			cust = new Customer();
			cust.CustomerName = "Microsoft Corporation";
			custColl.Add(cust);

			cust = new Customer();
			cust.CustomerName = "PDSA, Inc.";
			custColl.Add(cust);

			sb.Append("Count = " + custColl.Count.ToString());
			sb.Append(Environment.NewLine);

			foreach (Customer c in custColl)
				sb.Append(c.CustomerName + Environment.NewLine);

			lblMsg.Content = sb.ToString();

			custColl.RemoveAt(0);

			lblMsg.Content += "After the removal = " + custColl.Count;
		}
	}
}
