﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPF_Collections
{
	public class Customers : System.Collections.CollectionBase
	{
		public void Add(Customer cust)
		{
			base.List.Add(cust);
		}

		public void Remove(int Index)
		{
			if (Index > Count - 1 || Index < 0)
			{
				// Return error message
			}
			else
				base.List.RemoveAt(Index);
		}

		// This is the "Item" indexer
		public Customer this[int index]
		{
			get
			{
				if (index > Count - 1 || index < 0)
				{
					// Did not find Customer
					return null;
				}
				else
					return (Customer)base.List[index];
			}
		}
	}

}
