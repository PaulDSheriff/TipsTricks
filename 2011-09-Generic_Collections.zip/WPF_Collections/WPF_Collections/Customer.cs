﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPF_Collections
{
	public class Customer
	{
		public string CustomerName { get; set; }
	}
}
