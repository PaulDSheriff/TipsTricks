﻿using System;
using System.Windows;
using System.Windows.Controls;

using SL_LINQSearch.CustomerServiceReference;

namespace SL_LINQSearch
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private CustomerSearchClient _Client = null;

    private void btnGetCustomers_Click(object sender, RoutedEventArgs e)
    {
      _Client = new CustomerSearchClient();

      _Client.GetCustomersCompleted += new EventHandler<GetCustomersCompletedEventArgs>(_Client_GetCustomersCompleted);
      _Client.GetCustomersAsync(txtCompanyName.Text,
                  ((ComboBoxItem)cboCompanyOperator.SelectedItem).Content.ToString(),
                  txtEmail.Text,
                  ((ComboBoxItem)cboEmailOperator.SelectedItem).Content.ToString());
    }

    void _Client_GetCustomersCompleted(object sender, GetCustomersCompletedEventArgs e)
    {
      lstCustomers.DataContext = e.Result;

      _Client.CloseAsync();
    }
  }
}
