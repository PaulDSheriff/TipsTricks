﻿Imports SL_LINQSearch.CustomerServiceReference

Partial Public Class MainPage
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private WithEvents _Client As CustomerSearchClient

  Private Sub btnGetCustomers_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnGetCustomers.Click
    _Client = New CustomerSearchClient()

    _Client.GetCustomersAsync(txtCompanyName.Text, _
                DirectCast(cboCompanyOperator.SelectedItem, ComboBoxItem).Content.ToString(), _
                txtEmail.Text, _
                DirectCast(cboEmailOperator.SelectedItem, ComboBoxItem).Content.ToString())
  End Sub

  Private Sub _Client_GetCustomersCompleted(sender As Object, e As CustomerServiceReference.GetCustomersCompletedEventArgs) Handles _Client.GetCustomersCompleted
    lstCustomers.DataContext = e.Result

    _Client.CloseAsync()
  End Sub
End Class