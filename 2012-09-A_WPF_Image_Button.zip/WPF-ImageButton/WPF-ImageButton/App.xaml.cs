﻿using System.Windows;

namespace WPF_ImageButton
{
  public partial class App : Application
  {
  }
}
