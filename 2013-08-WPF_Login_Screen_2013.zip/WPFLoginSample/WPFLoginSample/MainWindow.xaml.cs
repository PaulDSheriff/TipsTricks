﻿using System.Windows;

namespace WPFLoginSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DisplayLoginScreen();
    }

    private void DisplayLoginScreen()
    {
      winLogin win = new winLogin();

      win.Owner = this;
      win.ShowDialog();
      if (win.DialogResult.HasValue && win.DialogResult.Value)
        MessageBox.Show("User Logged In");
      else
        this.Close();
    }
  }
}
