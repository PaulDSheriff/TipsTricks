﻿using System.Windows;

namespace WPFLoginSample
{
  public partial class winLogin : Window
  {
    public winLogin()
    {
      InitializeComponent();
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = false;
    }

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      // Write code here to authenticate user


      // If authenticated, then set DialogResult=true
      DialogResult = true;
    }
  }
}
