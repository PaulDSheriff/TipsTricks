﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLSortDataUsingCode
{
public class Product
{
  public Product(int id, string name, string type)
  {
    ProductId = id;
    ProductName = name;
    ProductType = type;
  }

  public int ProductId { get; set; }
  public string ProductName { get; set; }
  public string ProductType { get; set; }
}

public class Products : List<Product>
{
  public Products()
  {
    InitCollection();
  }

  public List<Product> DataCollection { get; set; }

  List<Product> InitCollection()
  {
    DataCollection = new List<Product>();

    DataCollection.Add(new Product(3, "PDSA Framework", "Product"));
    DataCollection.Add(new Product(1, "Haystack", "Product"));
    DataCollection.Add(new Product(2, "Fundamentals of .NET eBook", "Book"));

    return DataCollection;
  }
}
}
