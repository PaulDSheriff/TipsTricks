﻿using System;

namespace SLValueConverter
{
  public class Product
  {
    #region Constructors

    public Product()
    {
    }

    public Product(string name, decimal price, bool onSpecial)
    {
      this.ProductName = name;
      this.Price = price;
      this.IsOnSpecial = onSpecial;
    }
    #endregion

    public string ProductName { get; set; }
    public decimal Price { get; set; }
    public bool IsOnSpecial { get; set; }
  }
}