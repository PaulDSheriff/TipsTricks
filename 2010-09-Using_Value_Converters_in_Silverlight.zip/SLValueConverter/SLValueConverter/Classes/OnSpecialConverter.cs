﻿using System;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace SLValueConverter
{
  public class OnSpecialConverter : IValueConverter
  {
    public object Convert(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      BitmapImage img = new BitmapImage();

      if (System.Convert.ToBoolean(value))
      {
        img.UriSource = new Uri("../Images/OnSpecial.jpg", UriKind.Relative);
      }
      else
      {
        img.UriSource = new Uri("../Images/Blank.jpg", UriKind.Relative);
      }

      return img;
    }

    public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      return null;
    }
  }
}