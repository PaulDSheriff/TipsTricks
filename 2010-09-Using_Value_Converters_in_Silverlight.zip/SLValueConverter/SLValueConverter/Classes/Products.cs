﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace SLValueConverter
{
  public class Products : List<Product>
  {
    public Products()
    {
      BuildCollection();
    }

    public ObservableCollection<Product> DataCollection { get; set; }

    public ObservableCollection<Product> BuildCollection()
    {
      DataCollection = new ObservableCollection<Product>();

      DataCollection.Add(new Product("Haystack Code Generator for .NET", 799, true));
      DataCollection.Add(new Product("PDSA .NET Productivity Framework", 5000, true));
      DataCollection.Add(new Product("Fundamentals of N-Tier eBook", 20, false));
      DataCollection.Add(new Product("Fundamentals of ASP.NET Security eBook", 20, false));
      DataCollection.Add(new Product("Fundamentals of SQL Server eBook", 20, false));
      DataCollection.Add(new Product("Fundamentals of VB.NET eBook", 20, false));
      DataCollection.Add(new Product("Fundamentals of .NET eBook", 20, false));
      DataCollection.Add(new Product("Architecting ASP.NET eBook", 20, false));

      return DataCollection;
    }
  }
}