﻿Imports System.ServiceModel

<ServiceContract()>
Public Interface ICustomerSearch

  <OperationContract()>
  Function GetCustomers(cname As String, cnameOperator As String, email As String, emailOperator As String) As List(Of Customer)

End Interface
