﻿Imports System.Data.Objects

Public Class CustomerSearch
  Implements ICustomerSearch

  Public Function GetCustomers(cname As String, cnameOperator As String, email As String, emailOperator As String) As List(Of Customer) Implements ICustomerSearch.GetCustomers
    Dim db As New AdventureWorksLTEntities
    Dim join As String = " WHERE "
    Dim sql As String
    Dim query As ObjectQuery(Of Customer)

    sql = "SELECT VALUE cust FROM AdventureWorksLTEntities.Customers As cust "

    If String.IsNullOrEmpty(cname) = False Then
      sql &= join & " cust.CompanyName " & BuildWhere(cnameOperator, cname)
      join = " AND "
    End If
    If String.IsNullOrEmpty(email) = False Then
      sql &= join & " cust.EmailAddress " & BuildWhere(emailOperator, email)
      join = " AND "
    End If

    sql &= " ORDER BY cust.CompanyName"

    query = db.CreateQuery(Of Customer)(sql)

    Return query.ToList()
  End Function

  Public Function BuildWhere(operatorValue As String, value As String) As String
    Dim where As String = String.Empty

    Select Case operatorValue.ToLower()
      Case "equal to"
        where = " = '" & value & "'"

      Case "starts with"
        where = " LIKE '" & value & "%'"

      Case "contains"
        where = " LIKE '%" & value & "%'"

    End Select

    Return where
  End Function
End Class
