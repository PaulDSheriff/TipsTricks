﻿using System.Collections.Generic;
using System.ServiceModel;

namespace SL_LINQSearch.Web
{
  [ServiceContract]
  public interface ICustomerSearch
  {
    [OperationContract]
    List<Customer> GetCustomers(string cname, string cnameOperator, string email, string emailOperator);
  }
}
