﻿using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;

namespace SL_LINQSearch.Web
{
public class CustomerSearch : ICustomerSearch
{
  public List<Customer> GetCustomers(string cname, string cnameOperator, string email, string emailOperator)
  {
    AdventureWorksLTEntities db = new AdventureWorksLTEntities();
    string join = " WHERE ";
    string sql = null;
    ObjectQuery<Customer> query = default(ObjectQuery<Customer>);

    sql = "SELECT VALUE cust FROM AdventureWorksLTEntities.Customers As cust ";

    if (string.IsNullOrEmpty(cname) == false)
    {
      sql += join + " cust.CompanyName " + BuildWhere(cnameOperator, cname);
      join = " AND ";
    }
    if (string.IsNullOrEmpty(email) == false)
    {
      sql += join + " cust.EmailAddress " + BuildWhere(emailOperator, email);
      join = " AND ";
    }

    sql += " ORDER BY cust.CompanyName";

    query = db.CreateQuery<Customer>(sql);

    return query.ToList();
  }

  public string BuildWhere(string operatorValue, string value)
  {
    string where = string.Empty;

    switch (operatorValue.ToLower())
    {
      case "equal to":
        where = " = '" + value + "'";
        break;
      case "starts with":
        where = " LIKE '" + value + "%'";
        break;
      case "contains":
        where = " LIKE '%" + value + "%'";
        break;
    }

    return where;
  }
}
}
