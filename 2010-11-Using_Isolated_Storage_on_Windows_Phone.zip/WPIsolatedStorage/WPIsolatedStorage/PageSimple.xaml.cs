﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Text;
using System.Windows;
using System.Xml.Serialization;
using Microsoft.Phone.Controls;

namespace WPIsolatedStorage
{
  public partial class PageSimple : PhoneApplicationPage
  {
    private LastUser _User = new LastUser();
    private const string USER_KEY = "LastUser";

    public PageSimple()
    {
      InitializeComponent();
    }

    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      if (IsolatedStorageSettings.ApplicationSettings.Contains(USER_KEY))
        GetUser();

      this.DataContext = _User;
    }

    private void GetUser()
    {
      string xml;

      xml = IsolatedStorageSettings.ApplicationSettings[USER_KEY].ToString();
      using (MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(xml)))
      {
        XmlSerializer serializer = new XmlSerializer(typeof(LastUser));
        _User = (LastUser)serializer.Deserialize(ms);
      }
    }

    private void btnSubmit_Click(object sender, RoutedEventArgs e)
    {
      SaveUser();
      NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.Relative));
    }

    private void SaveUser()
    {
      string xml = string.Empty;

      using (MemoryStream ms = new MemoryStream())
      {
        XmlSerializer serializer = new XmlSerializer(typeof(LastUser));
        serializer.Serialize(ms, _User);
        ms.Position = 0;

        using (StreamReader reader = new StreamReader(ms))
          xml = reader.ReadToEnd();
      }

      // Store user in Isolated Storage
      IsolatedStorageSettings.ApplicationSettings[USER_KEY] = xml;
    }
  }
}