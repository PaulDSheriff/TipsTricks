﻿using System.ComponentModel;

namespace WPIsolatedStorage
{
  public class LastUser : INotifyPropertyChanged
  {
    #region INotifyPropertyChanged Event
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }
    #endregion

    #region Private Variables
    private string mFirstName = string.Empty;
    private string mLastName = string.Empty;
    private string mEmail = string.Empty;
    #endregion

    #region Public Variables
    public string FirstName
    {
      get { return mFirstName; }
      set
      {
        if (mFirstName != value)
        {
          mFirstName = value;
          RaisePropertyChanged("FirstName");
        }
      }
    }

    public string LastName
    {
      get { return mLastName; }
      set
      {
        if (mLastName != value)
        {
          mLastName = value;
          RaisePropertyChanged("LastName");
        }
      }
    }
    
    public string Email
    {
      get { return mEmail; }
      set
      {
        if (mEmail != value)
        {
          mEmail = value;
          RaisePropertyChanged("Email");
        }
      }
    }

    #endregion
  }
}
