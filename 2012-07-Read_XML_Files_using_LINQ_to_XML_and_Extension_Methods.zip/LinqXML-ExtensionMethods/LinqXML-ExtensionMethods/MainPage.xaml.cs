﻿using System;
using System.Windows;
using System.Windows.Controls;

// These are needed for working with LINQ to XML
using System.Linq;
using System.Xml.Linq;

// This Namespace contains the Product class
using ProductLibrary;
// This Namespace contains the extension methods
using Common.Library;

namespace LinqXML_ExtensionMethods
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }


    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      LoadProducts();
    }

    private void LoadProducts()
    {
      var xElem = XElement.Load(Product.XmlFile);

      // The following query uses extension methods to ensure a good value is returned
      var products = from elem in xElem.Descendants("Product")
                     orderby elem.Attribute("ProductName").Value
                     select new Product
                     {
                       ProductId = elem.Attribute("ProductId").GetAsInteger(),
                       ProductName = elem.Attribute("ProductName").GetAsString(),
                       IntroductionDate = elem.Attribute("IntroductionDate").GetAsDateTime(),
                       Price = elem.Attribute("Price").GetAsDecimal()
                     };

      lstData.DataContext = products;
    }
  }
}
