﻿using System.Windows;

namespace OverrideToString
{
  public partial class App : Application
  {
  }
}
