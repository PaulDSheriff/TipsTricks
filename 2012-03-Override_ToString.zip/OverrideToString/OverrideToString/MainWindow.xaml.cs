﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Documents;

namespace OverrideToString
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnCreate_Click(object sender, RoutedEventArgs e)
    {
      List<Product> coll = new List<Product>();
      Product prod;

      prod = new Product() { ProductName = "From Zero to HTML 5 in 60 Minutes", ProductId = 1 };
      coll.Add(prod);
      prod = new Product() { ProductName = "Architecting Applications for Multiple UIs", ProductId = 2 };
      coll.Add(prod);
      prod = new Product() { ProductName = "Introduction to Windows Phone Development", ProductId = 3 };
      coll.Add(prod);
      prod = new Product() { ProductName = "Architecting a Business Application for Windows Phone", ProductId = 4 };
      coll.Add(prod);
      prod = new Product() { ProductName = "Windows Phone Navigation & Tombstoning Techniques", ProductId = 5 };
      coll.Add(prod);
      prod = new Product() { ProductName = "MVVM Made Simple", ProductId = 6 };
      coll.Add(prod);
      prod = new Product() { ProductName = "From Zero to N-Tier (2011)", ProductId = 7 };
      coll.Add(prod);
      prod = new Product() { ProductName = "10 Tips to Spice up Your XAML Apps (Even if you are not a designer!)", ProductId = 8 };
      coll.Add(prod);
      prod = new Product() { ProductName = "14 Navigation Techniques for your XAML Applications", ProductId = 9 };
      coll.Add(prod);
      prod = new Product() { ProductName = "Silverlight XAML for the Complete Novice - Part 1", ProductId = 10 };
      coll.Add(prod);
      prod = new Product() { ProductName = "Silverlight XAML for the Complete Novice - Part 2", ProductId = 10 };
      coll.Add(prod);

      // If you forget DisplayMemberPath, ToString is used in ListBoxes, ComboBoxes etc.
      listBox1.DataContext = coll;

      System.Diagnostics.Debugger.Break();
    }
  }
}
