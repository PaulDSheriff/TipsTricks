﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace ListView_CreateColumns
{
  public class Product
  {
    #region Properties
    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public decimal Price { get; set; }
    #endregion

    #region GetProperties Method
public PropertyHeaders GetProperties()
{
  PropertyHeaders coll = new PropertyHeaders();

  coll.Add(new PropertyHeader("ProductId", "Product ID"));
  coll.Add(new PropertyHeader("ProductName", "Product Name"));
  coll.Add(new PropertyHeader("Price", "Price"));

  return coll;
}
    #endregion

    #region GetProducts Method
    public IEnumerable<Product> GetProducts(string fileName)
    {
      XElement elem = XElement.Load(fileName);

      var items = from prod in elem.Descendants("Product")
        select new Product
        {
          ProductId = Convert.ToInt32(prod.Element("ProductId").Value),
          ProductName = prod.Element("ProductName").Value,
          Price = Convert.ToDecimal(prod.Element("Price").Value)
        };

      return items;
    }
    #endregion
  }
}
