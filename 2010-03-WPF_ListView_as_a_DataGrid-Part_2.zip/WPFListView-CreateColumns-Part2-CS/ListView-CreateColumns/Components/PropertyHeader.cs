﻿using System.Collections.Generic;

namespace ListView_CreateColumns
{
  public class PropertyHeader
  {
    public PropertyHeader()
    {
    }

    public PropertyHeader(string propertyName, string headerText)
    {
      PropertyName = propertyName;
      HeaderText = headerText;
    }

    public string PropertyName { get; set; }
    public string HeaderText { get; set; }
  }

  public class PropertyHeaders : List<PropertyHeader>
  {
  }
}
  