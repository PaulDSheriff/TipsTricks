﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Xml.Linq

Public Class Product
#Region "Properties"
  Private mProductId As Integer
  Private mProductName As String
  Private mPrice As Decimal

  Public Property ProductId() As Integer
    Get
      Return mProductId
    End Get
    Set(ByVal value As Integer)
      mProductId = value
    End Set
  End Property

  Public Property ProductName() As String
    Get
      Return mProductName
    End Get
    Set(ByVal value As String)
      mProductName = value
    End Set
  End Property

  Public Property Price() As Decimal
    Get
      Return mPrice
    End Get
    Set(ByVal value As Decimal)
      mPrice = value
    End Set
  End Property
#End Region

#Region "GetProperties Method"
  Public Function GetProperties() As PropertyHeaders
    Dim coll As New PropertyHeaders()

    coll.Add(New PropertyHeader("ProductId", "Product ID"))
    coll.Add(New PropertyHeader("ProductName", "Product Name"))
    coll.Add(New PropertyHeader("Price", "Price"))

    Return coll
  End Function
#End Region

#Region "GetProducts Method"
  Public Function GetProducts(ByVal fileName As String) As IEnumerable(Of Product)
    Dim elem As XElement = XElement.Load(fileName)

    Dim items = From prod In elem.Descendants("Product") _
        Select New Product() With { _
          .ProductId = Convert.ToInt32(prod.Element("ProductId").Value), _
          .ProductName = prod.Element("ProductName").Value, _
          .Price = Convert.ToDecimal(prod.Element("Price").Value) _
        }

    Return items
  End Function
#End Region
End Class
