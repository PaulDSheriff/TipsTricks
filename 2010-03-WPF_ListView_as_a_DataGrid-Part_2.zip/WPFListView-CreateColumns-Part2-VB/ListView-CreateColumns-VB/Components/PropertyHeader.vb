﻿Imports System.Collections.Generic

Public Class PropertyHeader
  Public Sub New()
  End Sub

  Public Sub New(ByVal propName As String, ByVal header As String)
    PropertyName = propName
    HeaderText = header
  End Sub

  Private mPropertyName As String
  Private mHeaderText As String

  Public Property PropertyName() As String
    Get
      Return mPropertyName
    End Get
    Set(ByVal value As String)
      mPropertyName = value
    End Set
  End Property

  Public Property HeaderText() As String
    Get
      Return mHeaderText
    End Get
    Set(ByVal value As String)
      mHeaderText = value
    End Set
  End Property
End Class

Public Class PropertyHeaders
  Inherits List(Of PropertyHeader)
End Class
