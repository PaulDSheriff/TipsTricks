﻿Imports System.Configuration

Public Class AppSettings
#Region "Singleton of AppSettings"
  Private Shared _Instance As AppSettings = Nothing

  Public Shared ReadOnly Property Instance() As AppSettings
    Get
      If _Instance Is Nothing Then
        _Instance = New AppSettings()
      End If

      Return _Instance
    End Get
  End Property
#End Region

  Protected Function GetConnectionString(key As String) As String
    Return ConfigurationManager.ConnectionStrings(key).ConnectionString
  End Function

  Public ReadOnly Property ConnectString() As String
    Get
      Return GetConnectionString("Sandbox")
    End Get
  End Property
End Class
