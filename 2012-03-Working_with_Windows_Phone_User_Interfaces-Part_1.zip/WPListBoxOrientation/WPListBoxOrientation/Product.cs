﻿using System;

namespace WPListBoxOrientation
{
public class Product
{
  public Product()
  {
  }

  public Product(string name, decimal price, string imageUri)
  {
    this.ProductName = name;
    this.Price = price;
    this.ImageUri = imageUri;
  }

  public string ProductName { get; set; }
  public decimal Price { get; set; }
  public string ImageUri { get; set; }
}
}