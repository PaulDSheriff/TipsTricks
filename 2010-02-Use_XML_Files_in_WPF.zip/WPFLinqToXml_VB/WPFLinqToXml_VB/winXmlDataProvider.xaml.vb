﻿Partial Public Class winXmlDataProvider

End Class
