﻿Class WinMain

  Private Sub btnXMLData_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    Dim win As New winXmlDataProvider

    win.Show()
  End Sub

  Private Sub btnXMLDataSort_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    Dim win As New winXmlDataProviderSorting

    win.Show()
  End Sub

  Private Sub btnLinqXml_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    Dim win As New winLINQToXml

    win.Show()
  End Sub
End Class
