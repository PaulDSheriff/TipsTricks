﻿Partial Public Class winLINQToXml

  Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    ProductsLoad()
  End Sub

  Private Sub ProductsLoad()
    ' Set the Product.xml file to Build Action="Content" and 
    ' Copy to Output Directory="Copy Always" in Properties window 
    Dim xElem = XElement.Load("Product.xml")

    ' Get All Products 
    Dim products = From prod In xElem.Descendants("Product") _
        Order By prod.Element("ProductName").Value _
        Select prod.Element("ProductName").Value

    lstProducts.DataContext = products
  End Sub
End Class
