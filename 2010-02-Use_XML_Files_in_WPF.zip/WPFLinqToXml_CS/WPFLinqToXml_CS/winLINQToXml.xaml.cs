﻿using System.Linq;
using System.Windows;
using System.Xml.Linq;

namespace WPFLinqToXml_CS
{
  /// <summary>
  /// Interaction logic for winLINQToXml.xaml
  /// </summary>
  public partial class winLINQToXml : Window
  {
    public winLINQToXml()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ProductsLoad();
    }

    private void ProductsLoad()
    {
      // Set the Product.xml file to Build Action="Content" and 
      // Copy to Output Directory="Copy Always" in Properties window
      var xElem = XElement.Load(@"Product.xml");

      // Get All Products
      var products = from prod in xElem.Descendants("Product")
               orderby prod.Element("ProductName").Value
               select prod.Element("ProductName").Value;

      lstProducts.DataContext = products;
    }
  }
}
