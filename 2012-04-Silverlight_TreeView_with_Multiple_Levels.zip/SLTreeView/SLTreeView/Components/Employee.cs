﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SLTreeView
{
public class Employee
{
  public Employee(string name)
  {
    Name = name;
  }

  public string Name { get; set; }
}
}
