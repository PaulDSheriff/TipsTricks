﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLTreeView
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void tvEmps_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
      object current;

      current = tvEmps.SelectedItem;
      switch (current.GetType().Name.ToLower())
      {
        case "employee":
          break;
        case "employeetype":
          break;
        case "subemployee":
          break;
        default:
          break;
      }
    }
  }
}
