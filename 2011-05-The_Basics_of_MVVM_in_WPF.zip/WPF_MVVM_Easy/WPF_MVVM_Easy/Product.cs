﻿using System;

namespace WPF_MVVM_Easy
{
  public class Product
  {
    public string ProductName { get; set; }
  }
}
