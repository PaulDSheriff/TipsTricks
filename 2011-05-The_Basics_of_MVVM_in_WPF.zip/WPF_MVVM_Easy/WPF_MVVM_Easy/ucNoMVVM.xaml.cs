﻿using System;
using System.Configuration;
using System.Windows;
using System.Windows.Controls;

using System.Data;
using System.Data.SqlClient;

namespace WPF_MVVM_Easy
{
  public partial class ucNoMVVM : UserControl
  {
    public ucNoMVVM()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      GetProducts();
    }

    private void GetProducts()
    {
      Products coll = new Products();
      string sql = string.Empty;
      SqlDataAdapter da = null;
      DataTable dt = new DataTable();

      sql = "SELECT ProductName ";
      sql += " FROM Product ";

      // Create Data Adapter
      da = new SqlDataAdapter(sql,
        ConfigurationManager.
              ConnectionStrings["ConnectString"].
                ConnectionString);
      // Fill DataTable with Products
      da.Fill(dt);

      // Loop thru all rows
      // Create a new Product object each time thru
      foreach (DataRow dr in dt.Rows)
      {
        Product prod = new Product();

        prod.ProductName =
          Convert.ToString(dr["ProductName"]);

        coll.Add(prod);
      }

      // Fill in ListBox
      lstData.DataContext = coll;
    }
  }
}
