﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;

namespace WPF_MVVM_Easy
{
  public class ProductViewModel : INotifyPropertyChanged
  {
    #region INotifyPropertyChanged
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// The event is only invoked if data binding is used
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler handler = this.PropertyChanged;
      if (handler != null)
      {
        PropertyChangedEventArgs args = new PropertyChangedEventArgs(propertyName);

        // Raise the PropertyChanged event.
        handler(this, args);
      }
    }
    #endregion

    #region DataCollection Property
    private Products _DataCollection;

    public Products DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region GetProducts Method
    public void GetProducts()
    {
      Products coll = new Products();
      string sql = string.Empty;
      SqlDataAdapter da = null;
      DataTable dt = new DataTable();

      sql = "SELECT ProductName ";
      sql += " FROM Product ";

      // Create Data Adapter
      da = new SqlDataAdapter(sql,
        ConfigurationManager.
              ConnectionStrings["ConnectString"].
                ConnectionString);
      // Fill DataTable with Products
      da.Fill(dt);

      // Loop thru all rows
      // Create a new Product object each time thru
      foreach (DataRow dr in dt.Rows)
      {
        Product prod = new Product();

        prod.ProductName =
          Convert.ToString(dr["ProductName"]);

        coll.Add(prod);
      }

      // Assign to DataCollection property to raise PropertyChanged event
      DataCollection = coll;
    }
    #endregion
  }
}
