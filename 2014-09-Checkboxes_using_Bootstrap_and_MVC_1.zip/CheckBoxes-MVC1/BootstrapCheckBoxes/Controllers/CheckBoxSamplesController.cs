﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;

namespace BootstrapCheckBoxes.Controllers
{
  public class CheckBoxSamplesController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }

    public ActionResult Check01()
    {
      return View();
    }

    public ActionResult Check02()
    {
      return View();
    }

    public ActionResult Check03()
    {
      return View();
    }

    public ActionResult Check04()
    {
      return View();
    }

    public ActionResult Check05()
    {
      return View();
    }
  }
}