﻿Imports System.DirectoryServices

Namespace PDSA.ActiveDirectory
  Public Class PDSAActiveDirectory
    ''' <summary> 
    ''' Returns the default LDAP Path on the current network 
    ''' </summary> 
    ''' <returns>An LDAP Path</returns> 
    Public Shared Function GetDefaultLDAPPath() As String
      Try
        Dim de As DirectoryEntry = Nothing
        Dim ds As New DirectorySearcher(de)
        Dim sr As SearchResult = ds.FindOne()

        Return sr.Path
      Catch
        Return "No LDAP Server available, are you connected to a network?"
      End Try
    End Function
  End Class
End Namespace