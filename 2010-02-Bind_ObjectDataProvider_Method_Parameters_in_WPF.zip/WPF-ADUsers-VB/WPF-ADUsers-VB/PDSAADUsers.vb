﻿Imports System.DirectoryServices
Imports System.Collections.Generic

Namespace PDSA.ActiveDirectory
  Public Class PDSAADUsers
    Inherits List(Of PDSAADUser)

    Public Sub New()
      AllowAllUsers = False
    End Sub

    Private mAllowAllUsers As Boolean

    Public Property AllowAllUsers() As Boolean
      Get
        Return mAllowAllUsers
      End Get
      Set(ByVal value As Boolean)
        mAllowAllUsers = value
      End Set
    End Property

#Region "GetUsers Method"
    Public Function GetUsers(ByVal partialUserName As String) As PDSAADUsers
      Dim coll As New PDSAADUsers()
      Dim ldapPath As String

      ldapPath = GetDefaultServer()
      If ldapPath <> String.Empty Then
        Return GetUsers(ldapPath, partialUserName)
      Else
        Dim entity As PDSAADUser

        ' Create a default user 
        entity = New PDSAADUser()
        entity.Name = "Can't Find LDAP Server"
        entity.DistinguishedName = "Are you connected to the network?"
        coll.Add(entity)

        Return coll
      End If
    End Function

    Public Function GetUsers(ByVal ldapPath As String, ByVal partialUserName As String) As PDSAADUsers
      Dim coll As New PDSAADUsers()
      Dim entity As PDSAADUser
      Dim de As DirectoryEntry
      Dim dSearch As DirectorySearcher
      Dim results As SearchResultCollection

      ' Make sure there is a default LDAP Path 
      If ldapPath = String.Empty Then
        ldapPath = GetDefaultServer()
      End If

      ' Create a Directory Entry object 
      de = New DirectoryEntry(ldapPath)
      ' Create a DirectorySearcher object 
      dSearch = New DirectorySearcher(de)
      ' Create list of properties to retrieve from AD 
      dSearch.PropertiesToLoad.Add("name")
      dSearch.PropertiesToLoad.Add("distinguishedName")

      ' Setup the search filter 
      If partialUserName.Trim() = String.Empty Then
        dSearch.Filter = "(objectCategory=user)"
      Else
        dSearch.Filter = "(&(objectCategory=user)(SAMAccountName=" & partialUserName & "*))"
      End If

      If Not AllowAllUsers AndAlso partialUserName = String.Empty Then
        ' Create a default user 
        entity = New PDSAADUser()
        entity.Name = "Please Filter"
        entity.DistinguishedName = "Too many users would be returned"
        coll.Add(entity)
      Else
        ' Perform the active directory search 
        results = dSearch.FindAll()

        ' Loop through results and build a user object 
        For Each sr As SearchResult In results
          entity = New PDSAADUser()
          entity.Name = sr.Properties("name")(0).ToString()
          entity.DistinguishedName = sr.Properties("distinguishedname")(0).ToString()

          coll.Add(entity)
        Next
      End If

      Return coll
    End Function
#End Region

#Region "GetDefaultServer Method"
    Public Function GetDefaultServer() As String
      Try
        Dim de As DirectoryEntry = Nothing
        Dim ds As New DirectorySearcher(de)
        Dim sr As SearchResult = ds.FindOne()

        Return sr.Path
      Catch
        Return String.Empty
      End Try
    End Function
#End Region
  End Class
End Namespace