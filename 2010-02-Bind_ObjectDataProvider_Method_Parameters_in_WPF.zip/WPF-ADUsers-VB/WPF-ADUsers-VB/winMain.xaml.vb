﻿Class winMain
End Class
