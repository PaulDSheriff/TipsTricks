﻿Namespace PDSA.ActiveDirectory
  Public Class PDSAADUser
    Private mName As String
    Private mDistinguishedName As String

    Public Property Name() As String
      Get
        Return mName
      End Get
      Set(ByVal value As String)
        mName = value
      End Set
    End Property

    Public Property DistinguishedName() As String
      Get
        Return mDistinguishedName
      End Get
      Set(ByVal value As String)
        mDistinguishedName = value
      End Set
    End Property
  End Class
End Namespace