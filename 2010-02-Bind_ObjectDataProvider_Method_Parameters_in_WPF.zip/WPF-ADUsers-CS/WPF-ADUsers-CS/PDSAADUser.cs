﻿namespace PDSA.ActiveDirectory
{
  public class PDSAADUser
  {
    public string Name { get; set; }
    public string DistinguishedName { get; set; }
  }
}
