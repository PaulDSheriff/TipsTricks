﻿using System.Windows;
using PDSA.ActiveDirectory;

namespace WPF_ADUsers_CS
{
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }
  }
}
