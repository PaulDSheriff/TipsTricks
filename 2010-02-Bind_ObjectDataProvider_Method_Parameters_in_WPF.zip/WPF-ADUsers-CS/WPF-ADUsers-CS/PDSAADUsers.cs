﻿using System.DirectoryServices;
using System.Collections.Generic;

namespace PDSA.ActiveDirectory
{
  public class PDSAADUsers : List<PDSAADUser>
  {
    public PDSAADUsers()
    {
      AllowAllUsers = false;
    }

    public bool AllowAllUsers { get; set; }

    #region GetUsers Method
    public PDSAADUsers GetUsers(string partialUserName)
    {
      PDSAADUsers coll = new PDSAADUsers();
      string ldapPath;

      ldapPath = GetDefaultServer();
      if (ldapPath != string.Empty)
        return GetUsers(ldapPath, partialUserName);
      else
      {
        PDSAADUser entity;

        // Create a default user
        entity = new PDSAADUser();
        entity.Name = "Can't Find LDAP Server";
        entity.DistinguishedName = "Are you connected to the network?";
        coll.Add(entity);

        return coll;
      }
    }

    public PDSAADUsers GetUsers(string ldapPath, string partialUserName)
    {
      PDSAADUsers coll = new PDSAADUsers();
      PDSAADUser entity;
      DirectoryEntry de;
      DirectorySearcher dSearch;
      SearchResultCollection results;

      // Make sure there is a default LDAP Path
      if (ldapPath == string.Empty)
        ldapPath = GetDefaultServer();

      // Create a Directory Entry object
      de = new DirectoryEntry(ldapPath);
      // Create a DirectorySearcher object
      dSearch = new DirectorySearcher(de);
      // Create list of properties to retrieve from AD
      dSearch.PropertiesToLoad.Add("name");
      dSearch.PropertiesToLoad.Add("distinguishedName");

      // Setup the search filter
      if (partialUserName.Trim() == string.Empty)
        dSearch.Filter = "(objectCategory=user)";
      else
        dSearch.Filter = "(&(objectCategory=user)(SAMAccountName=" +
                           partialUserName + "*))";

      if (!AllowAllUsers && partialUserName == string.Empty)
      {
        // Create a default user
        entity = new PDSAADUser();
        entity.Name = "Please Filter";
        entity.DistinguishedName = "Too many users would be returned";
        coll.Add(entity);
      }
      else
      {
        // Perform the active directory search
        results = dSearch.FindAll();

        // Loop through results and build a user object
        foreach (SearchResult sr in results)
        {
          entity = new PDSAADUser();
          entity.Name = sr.Properties["name"][0].ToString();
          entity.DistinguishedName =
            sr.Properties["distinguishedname"][0].ToString();

          coll.Add(entity);
        }
      }

      return coll;
    }
    #endregion

    #region GetDefaultServer Method
    public string GetDefaultServer()
    {
      try
      {
        DirectoryEntry de = default(DirectoryEntry);
        DirectorySearcher ds = new DirectorySearcher(de);
        SearchResult sr = ds.FindOne();

        return sr.Path;
      }
      catch
      {
        return string.Empty;
      }
    }
    #endregion
  }
}