﻿using System.Windows;

namespace WindowInheritance
{
  /// <summary>
  /// Interaction logic for frmMain.xaml
  /// </summary>
  public partial class frmMain : WindowBase
  {
    public frmMain()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      lblDesignMode.Text = base.IsInDesignMode.ToString();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      string fileName;

      fileName = base.GetCurrentDirectory() +
                   @"\Dictionaries\" + txtXamlName.Text;

      base.OpenResourceDictionary(fileName);
    }

  }
}
