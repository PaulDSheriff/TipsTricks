﻿Imports System
Imports System.ComponentModel
Imports System.IO
Imports System.Windows
Imports System.Windows.Markup

Public Class WindowBase
  Inherits Window

  ''' <summary>
  ''' Returns a true if the Window object is in design mode, or false if in runtime mode.
  ''' </summary>
  ''' <returns>Boolean</returns>
  Public ReadOnly Property IsInDesignMode() As Boolean
    Get
      Return DesignerProperties.GetIsInDesignMode(Me)
    End Get
  End Property

  ''' <summary>
  ''' Load and Merge a Resource Dictionary in a XAML file on disk into the current Window object
  ''' </summary>
  ''' <param name="fileName">The full path and file name of the XAML file.</param>
  Public Sub OpenResourceDictionary(ByVal fileName As String)
    Dim dic As ResourceDictionary = Nothing

    If File.Exists(fileName) Then
      Using fs As New FileStream(fileName, FileMode.Open)
        dic = DirectCast(XamlReader.Load(fs), ResourceDictionary)
      End Using

      Me.Resources.MergedDictionaries.Add(dic)
    Else
      Throw New FileNotFoundException("Can't open resource file: " & fileName & " in the method WPFCommon.OpenResourceDictionary().")
    End If
  End Sub

  Public Function GetCurrentDirectory() As String
    Dim path As String = Nothing

    path = AppDomain.CurrentDomain.BaseDirectory
    If path.IndexOf("\bin") > 0 Then
      path = path.Substring(0, path.LastIndexOf("\bin"))
    End If

    Return path
  End Function
End Class