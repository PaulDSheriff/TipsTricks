﻿using System;
using Microsoft.Phone.Controls;

namespace WPAppBar
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }

    private void ApplicationBarIconButton_Click(object sender, EventArgs e)
    {
      if (sender is Microsoft.Phone.Shell.ApplicationBarIconButton)
        tbMessage.Text = "Icon Clicked";
      else if (sender is Microsoft.Phone.Shell.ApplicationBarMenuItem)
        tbMessage.Text = "Menu Clicked";
    }
  }
}