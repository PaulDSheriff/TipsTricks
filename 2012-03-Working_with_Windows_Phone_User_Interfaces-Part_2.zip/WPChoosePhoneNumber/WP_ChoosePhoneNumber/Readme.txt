﻿This is an example of a "Chooser"
You call the Phone Number Chooser App
Your app is not necessarily tombstoned, just temporarily deactivated
In the Completed event the phone number from the app is returned.
