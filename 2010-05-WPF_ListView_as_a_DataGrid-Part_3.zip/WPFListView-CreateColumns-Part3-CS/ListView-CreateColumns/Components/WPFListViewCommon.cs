﻿using System;
using System.Data;
using System.Windows.Controls;
using System.Windows.Data;

using System.Reflection;

namespace ListView_CreateColumns
{
  public class WPFListViewCommon
  {
    #region CreateGridViewColumns Method for Type
    /// <summary>
    /// 
    /// </summary>
    /// <example>
    ///  lstXML.View = PDSAWPFListView.CreateGridViewColumns(typeOf(Product));
    ///  lstXML.DataContext = dt;
    /// </example>
    /// <param name="anyType">A Type to extract properties from</param>
    /// <returns>GridView Object</returns>
    public static GridView CreateGridViewColumns(Type anyType)
    {
      // Create the GridView
      GridView gv = new GridView();
      GridViewColumn gvc;

      // Get the public properties.
      PropertyInfo[] propInfo = anyType.GetProperties(BindingFlags.Public | BindingFlags.Instance);

      foreach (PropertyInfo item in propInfo)
      {
        gvc = new GridViewColumn();
        gvc.DisplayMemberBinding = new Binding(item.Name);
        gvc.Header = item.Name;
        gvc.Width = Double.NaN;
        gv.Columns.Add(gvc);
      }

      return gv;
    }
    #endregion
  }
}
