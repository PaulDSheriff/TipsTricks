﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace ListView_CreateColumns
{
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    private void btnCollection_Click(object sender, RoutedEventArgs e)
    {
      CollectionSample();
    }

    private void CollectionSample()
    {
      Product prod = new Product();

      // Setup the GridView Columns
      lstData.View = WPFListViewCommon.CreateGridViewColumns(typeof(Product));
      lstData.DataContext =
        prod.GetProducts(GetCurrentDirectory() + @"\Xml\Product.xml");
    }

    #region GetCurrentDirectory Method
    public static string GetCurrentDirectory()
    {
      string path = null;

      path = AppDomain.CurrentDomain.BaseDirectory;
      if (path.IndexOf(@"\bin") > 0)
      {
        path = path.Substring(0, path.LastIndexOf(@"\bin"));
      }

      return path;
    }
    #endregion

  }
}
