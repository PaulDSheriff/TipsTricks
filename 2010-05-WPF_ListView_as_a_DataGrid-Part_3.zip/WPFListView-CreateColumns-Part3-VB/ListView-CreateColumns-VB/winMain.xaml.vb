﻿Class winMain
  Private Sub btnCollection_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    CollectionSample()
  End Sub

  Private Sub CollectionSample()
    Dim prod As New Product()

    ' Setup the GridView Columns
    lstData.View = WPFListViewCommon.CreateGridViewColumns(GetType(Product))
    lstData.DataContext = prod.GetProducts(GetCurrentDirectory() & "\Xml\Product.xml")
  End Sub

#Region "GetCurrentDirectory Method"
  Public Shared Function GetCurrentDirectory() As String
    Dim path As String = Nothing

    path = AppDomain.CurrentDomain.BaseDirectory
    If path.IndexOf("\bin") > 0 Then
      path = path.Substring(0, path.LastIndexOf("\bin"))
    End If

    Return path
  End Function
#End Region
End Class