﻿Imports System
Imports System.Data
Imports System.Windows.Controls
Imports System.Windows.Data

' Added these for doing Reflection 
Imports System.Reflection

Public Class WPFListViewCommon
#Region "CreateGridViewColumns Method for Type"
  ''' <summary> 
  ''' 
  ''' </summary> 
  ''' <example> 
  ''' lstXML.View = PDSAWPFListView.CreateGridViewColumns(typeOf(Product)); 
  ''' lstXML.DataContext = dt; 
  ''' </example> 
  ''' <param name="anyType">A Type to extract properties from</param> 
  ''' <returns>GridView Object</returns> 
  Public Shared Function CreateGridViewColumns(ByVal anyType As Type) As GridView
    ' Create the GridView 
    Dim gv As New GridView()
    Dim gvc As GridViewColumn

    ' Get the public properties. 
    Dim propInfo As PropertyInfo() = anyType.GetProperties(BindingFlags.Public Or BindingFlags.Instance)

    For Each item As PropertyInfo In propInfo
      gvc = New GridViewColumn()
      gvc.DisplayMemberBinding = New Binding(item.Name)
      gvc.Header = item.Name
      gvc.Width = [Double].NaN
      gv.Columns.Add(gvc)
    Next

    Return gv
  End Function
#End Region
End Class