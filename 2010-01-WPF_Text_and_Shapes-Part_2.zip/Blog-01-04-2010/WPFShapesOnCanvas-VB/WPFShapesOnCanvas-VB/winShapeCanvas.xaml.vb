﻿Class winShapeCanvas

End Class
