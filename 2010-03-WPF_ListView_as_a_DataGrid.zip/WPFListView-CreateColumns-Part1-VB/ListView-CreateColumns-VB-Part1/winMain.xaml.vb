﻿Imports System.Data

Class winMain
  Private Sub btnFirstSample_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    FirstSample()
  End Sub

  Private Sub FirstSample()
    ' Read the data
    Dim ds As New DataSet()
    ds.ReadXml(GetCurrentDirectory() & "\Xml\Product.xml")

    ' Create the GridView
    Dim gv As New GridView()

    ' Create the GridView Columns
    For Each item As DataColumn In ds.Tables(0).Columns
      Dim gvc As New GridViewColumn()
      gvc.DisplayMemberBinding = New Binding(item.ColumnName)
      gvc.Header = item.ColumnName
      gvc.Width = [Double].NaN
      gv.Columns.Add(gvc)
    Next

    ' Setup the GridView Columns
    lstData.View = gv
    ' Display the Data
    lstData.DataContext = ds.Tables(0)
  End Sub

  Private Sub btnDataTable_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    DataTableSample()
  End Sub

  Private Sub DataTableSample()
    ' Read the data
    Dim ds As New DataSet()
    ds.ReadXml(GetCurrentDirectory() & "\Xml\Product.xml")

    ' Setup the GridView Columns
    lstData.View = WPFListViewCommon.CreateGridViewColumns(ds.Tables(0))
    lstData.DataContext = ds.Tables(0)
  End Sub

#Region "GetCurrentDirectory Method"
  Public Shared Function GetCurrentDirectory() As String
    Dim path As String = Nothing

    path = AppDomain.CurrentDomain.BaseDirectory
    If path.IndexOf("\bin") > 0 Then
      path = path.Substring(0, path.LastIndexOf("\bin"))
    End If

    Return path
  End Function
#End Region

End Class
