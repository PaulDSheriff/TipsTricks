﻿Imports System
Imports System.Data
Imports System.Windows.Controls
Imports System.Windows.Data

Public Class WPFListViewCommon
#Region "CreateGridViewColumns Method for DataTable"
  Public Shared Function CreateGridViewColumns(ByVal dt As DataTable) As GridView
    ' Create the GridView
    Dim gv As New GridView()
    gv.AllowsColumnReorder = True

    ' Create the GridView Columns
    For Each item As DataColumn In dt.Columns
      Dim gvc As New GridViewColumn()
      gvc.DisplayMemberBinding = New Binding(item.ColumnName)
      gvc.Header = item.ColumnName
      gvc.Width = [Double].NaN
      gv.Columns.Add(gvc)
    Next

    Return gv
  End Function
#End Region
End Class