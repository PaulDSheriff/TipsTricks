﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace ListView_CreateColumns
{
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    private void btnFirstSample_Click(object sender, RoutedEventArgs e)
    {
      FirstSample();
    }

    private void FirstSample()
    {
      // Read the data
      DataSet ds = new DataSet();
      ds.ReadXml(GetCurrentDirectory() + @"\Xml\Product.xml");

      // Create the GridView
      GridView gv = new GridView();

      // Create the GridView Columns
      foreach (DataColumn item in ds.Tables[0].Columns)
      {
        GridViewColumn gvc = new GridViewColumn();
        gvc.DisplayMemberBinding = new Binding(item.ColumnName);
        gvc.Header = item.ColumnName;
        gvc.Width = Double.NaN;
        gv.Columns.Add(gvc);
      }

      // Setup the GridView Columns
      lstData.View = gv;
      // Display the Data
      lstData.DataContext = ds.Tables[0];
    }

    private void btnDataTable_Click(object sender, RoutedEventArgs e)
    {
      DataTableSample();
    }

    private void DataTableSample()
    {
      // Read the data
      DataSet ds = new DataSet();
      ds.ReadXml(GetCurrentDirectory() + @"\Xml\Product.xml");

      // Setup the GridView Columns
      lstData.View = WPFListViewCommon.CreateGridViewColumns(ds.Tables[0]);
      lstData.DataContext = ds.Tables[0];
    }

    #region GetCurrentDirectory Method
    public static string GetCurrentDirectory()
    {
      string path = null;

      path = AppDomain.CurrentDomain.BaseDirectory;
      if (path.IndexOf(@"\bin") > 0)
      {
        path = path.Substring(0, path.LastIndexOf(@"\bin"));
      }

      return path;
    }
    #endregion
  }
}
