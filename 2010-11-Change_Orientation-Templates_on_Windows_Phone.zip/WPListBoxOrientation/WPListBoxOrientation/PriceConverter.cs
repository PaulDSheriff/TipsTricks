﻿using System;
using System.Windows.Data;

namespace WPListBoxOrientation
{
  public class PriceConverter : IValueConverter
  {
    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      decimal price;

      price = (decimal)value;

      return price.ToString("c");
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new NotImplementedException();
    }
  }
}
