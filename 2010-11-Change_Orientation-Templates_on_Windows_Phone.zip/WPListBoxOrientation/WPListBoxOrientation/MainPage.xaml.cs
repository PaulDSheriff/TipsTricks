﻿using System.Windows;
using Microsoft.Phone.Controls;

namespace WPListBoxOrientation
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }

    private void PhoneApplicationPage_OrientationChanged(object sender, OrientationChangedEventArgs e)
    {      
      if (e.Orientation.ToString().Contains("Portrait"))
        lstData.ItemTemplate = 
          (DataTemplate)this.Resources["listPortrait"];
      else
        lstData.ItemTemplate = 
          (DataTemplate)this.Resources["listLandscape"];
    }
  }
}