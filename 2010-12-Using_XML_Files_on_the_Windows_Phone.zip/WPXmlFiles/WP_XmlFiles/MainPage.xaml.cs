﻿using System;
using System.Linq;
using System.Windows;
using System.Xml.Linq;
using Microsoft.Phone.Controls;

namespace WP_XmlFiles
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }

    private const string PROD_FILE = "Xml/Product.xml";

    #region Load Xml into List Box
    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      LoadProducts();
    }

    private void LoadProducts()
    {
      var xElem = XElement.Load(PROD_FILE);

      var products = from elem in xElem.Descendants("Product")
                     orderby elem.Attribute("ProductName").Value
                     select new Product
                     {
                       ProductId = Convert.ToInt32(elem.Attribute("ProductId").Value),
                       ProductName = elem.Attribute("ProductName").Value,
                       IntroductionDate = Convert.ToDateTime(elem.Attribute("IntroductionDate").Value),
                       Price = Convert.ToDecimal(elem.Attribute("Price").Value)
                     };

      lstData.DataContext = products;
    }
    #endregion
  }
}