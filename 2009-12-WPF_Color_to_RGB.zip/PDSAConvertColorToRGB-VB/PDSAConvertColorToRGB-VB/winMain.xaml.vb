﻿Imports System.Diagnostics
Imports System.Reflection

Class winMain
#Region "Retrieve Properties"
  Private Sub GetColorEnumsAsString()
    Dim clrs As PropertyInfo() = Type.GetType( _
      "System.Windows.Media.Colors, PresentationCore, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35").GetProperties()

    For Each item As System.Reflection.PropertyInfo In clrs
      Debug.WriteLine(item.Name)
    Next
  End Sub
#End Region

  Private Sub btnGetColor_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    Dim clr As New Color()

    clr = DirectCast(ColorConverter.ConvertFromString( _
                     lstColors.SelectedValue.ToString()), Color)

    lblRed.Content = clr.R.ToString()
    lblGreen.Content = clr.G.ToString()
    lblBlue.Content = clr.B.ToString()
  End Sub
End Class