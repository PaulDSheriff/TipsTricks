﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Windows;
using System.Windows.Media;

namespace PDSAConvertColorToRGB
{
  /// <summary>
  /// Interaction logic for winMain.xaml
  /// </summary>
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    #region Retrieve Properties
    private void GetColorEnumsAsString()
    {
      PropertyInfo[] clrs = Type.GetType(
        "System.Windows.Media.Colors, PresentationCore, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35").GetProperties();

      foreach (PropertyInfo item in clrs)
      {
        Debug.WriteLine(item.Name);
      }
    }
    #endregion

    private void btnGetColor_Click(object sender, RoutedEventArgs e)
    {
      Color clr = new Color();

      clr = (Color)ColorConverter.ConvertFromString(
        lstColors.SelectedValue.ToString());

      lblRed.Content = clr.R.ToString();
      lblGreen.Content = clr.G.ToString();
      lblBlue.Content = clr.B.ToString();
    }
  }
}
