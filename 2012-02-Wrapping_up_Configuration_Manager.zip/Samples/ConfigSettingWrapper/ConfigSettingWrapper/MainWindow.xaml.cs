﻿using System;
using System.Configuration;
using System.Windows;

namespace ConfigSettingWrapper
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnReadDirectly_Click(object sender, RoutedEventArgs e)
    {
      string value = string.Empty;

      value = ConfigurationManager.AppSettings["XmlPath"];
      value += @"\Customers.xml";

      MessageBox.Show(value);
    }

    private void btnWithChecking_Click(object sender, RoutedEventArgs e)
    {
      string value = string.Empty;

      value = ConfigurationManager.AppSettings["XmlPath"];
      if (value == null)
        value = @"C:\";

      value += @"\Customers.xml";

      MessageBox.Show(value);
    }

    private void btnAddWrapper_Click(object sender, RoutedEventArgs e)
    {
      AppConfig config = new AppConfig();

      config.XmlPath = config.GetSetting("XmlPath", @"C:\");

      MessageBox.Show(config.XmlPath);
    }

    private void btnWrapperNumeric_Click(object sender, RoutedEventArgs e)
    {
      AppConfig config = new AppConfig();

      config.DefaultType = config.GetSetting("DefaultType", 1);

      MessageBox.Show(config.DefaultType.ToString());
    }
  }
}
