﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLFilterData
{
  public class Product
  {
    public Product(int id, string name)
    {
      ProductId = id;
      ProductName = name;
    }

    public int ProductId { get; set; }
    public string ProductName { get; set; }
  }

  public class Products : List<Product>
  {
    public Products()
    {
      InitCollection();
    }

    public List<Product> DataCollection { get; set; }

List<Product> InitCollection()
{
  DataCollection = new List<Product>();

  DataCollection.Add(new Product(1, "PDSA Framework"));
  DataCollection.Add(new Product(2, "Haystack"));
  DataCollection.Add(new Product(3, "Fundamentals of .NET eBook"));
  DataCollection.Add(new Product(4, "WPF Fundamentals Video"));
  DataCollection.Add(new Product(5, "Fundamentals of ASP.NET Security eBook"));
  DataCollection.Add(new Product(6, "Fundamentals of SQL Server eBook"));
  DataCollection.Add(new Product(7, "Microsoft VS.NET 2010"));
  DataCollection.Add(new Product(8, "Microsoft Silverlight 4"));

  return DataCollection;
}
  }
}
