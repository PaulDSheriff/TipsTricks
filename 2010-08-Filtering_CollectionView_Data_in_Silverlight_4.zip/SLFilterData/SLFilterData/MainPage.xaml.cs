﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace SLFilterData
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnSearch_Click(object sender, RoutedEventArgs e)
    {
      FilterData();
    }

    private void FilterData()
    {
      if (lstData != null)
      {
        ICollectionView dataView = default(ICollectionView);

        dataView = (ICollectionView)lstData.ItemsSource;

        dataView.Filter = prod => ((Product)prod).ProductName.ToLower().StartsWith(txtName.Text.ToLower());

        lstData.ItemsSource = dataView;
      }
    }
  }
}
