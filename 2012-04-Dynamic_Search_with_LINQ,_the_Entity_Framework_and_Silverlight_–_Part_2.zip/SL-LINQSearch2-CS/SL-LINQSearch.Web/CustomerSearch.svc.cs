﻿using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;

namespace SL_LINQSearch.Web
{
  public class CustomerSearch : ICustomerSearch
  {
    public List<Customer> GetCustomers(string cname, string cnameOperator, string email, string emailOperator)
    {
      AdventureWorksLTEntities db = new AdventureWorksLTEntities();

      var query = from cust in db.Customers select cust;

      if (string.IsNullOrEmpty(cname) == false)
      {
        switch (cnameOperator.ToLower())
        {
          case "equal to":
            query = query.Where(cust => cust.CompanyName.Equals(cname));
            break;
          case "starts with":
            query = query.Where(cust => cust.CompanyName.StartsWith(cname));
            break;
          case "contains":
            query = query.Where(cust => cust.CompanyName.Contains(cname));
            break;
        }
      }
      if (string.IsNullOrEmpty(email) == false)
      {
        switch (emailOperator.ToLower())
        {
          case "equal to":
            query = query.Where(cust => cust.EmailAddress.Equals(email));
            break;
          case "starts with":
            query = query.Where(cust => cust.EmailAddress.StartsWith(email));
            break;
          case "contains":
            query = query.Where(cust => cust.EmailAddress.Contains(email));
            break;
        }
      }

      query = query.OrderBy(cust => cust.CompanyName);

      return query.ToList();
    }
  }
}
