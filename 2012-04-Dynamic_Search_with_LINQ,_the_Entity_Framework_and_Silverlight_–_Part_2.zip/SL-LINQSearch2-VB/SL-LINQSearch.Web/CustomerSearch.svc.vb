﻿Imports System.Data.Objects

Public Class CustomerSearch
  Implements ICustomerSearch

  Public Function GetCustomers(cname As String, cnameOperator As String, email As String, emailOperator As String) As List(Of Customer) Implements ICustomerSearch.GetCustomers
    Dim db As New AdventureWorksLTEntities

    Dim query = From cust In db.Customers Select cust

    If String.IsNullOrEmpty(cname) = False Then
      Select Case cnameOperator.ToLower()
        Case "equal to"
          query = query.Where(Function(cust) cust.CompanyName.Equals(cname))

        Case "starts with"
          query = query.Where(Function(cust) cust.CompanyName.StartsWith(cname))

        Case "contains"
          query = query.Where(Function(cust) cust.CompanyName.Contains(cname))

      End Select
    End If
    If String.IsNullOrEmpty(email) = False Then
      Select Case emailOperator.ToLower()
        Case "equal to"
          query = query.Where(Function(cust) cust.EmailAddress.Equals(email))

        Case "starts with"
          query = query.Where(Function(cust) cust.EmailAddress.StartsWith(email))

        Case "contains"
          query = query.Where(Function(cust) cust.EmailAddress.Contains(email))

      End Select
    End If

    query = query.OrderBy(Function(cust) cust.CompanyName)

    Return query.ToList()
  End Function
End Class
