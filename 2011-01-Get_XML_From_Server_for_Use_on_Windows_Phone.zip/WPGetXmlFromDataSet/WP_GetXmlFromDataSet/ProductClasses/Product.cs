﻿using System;

namespace WP_GetXmlFromDataSet
{
  public class Product
  {
    #region Public Properties
    public string ProductName { get; set; }
    public int ProductId { get; set; }
    public DateTime IntroductionDate { get; set; }
    public decimal Price { get; set; }
    #endregion
  }
}
