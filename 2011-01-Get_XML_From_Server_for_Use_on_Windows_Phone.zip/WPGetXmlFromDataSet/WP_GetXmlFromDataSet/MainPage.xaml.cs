﻿using System;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Windows;
using System.Xml.Linq;
using Microsoft.Phone.Controls;
using WP_GetXmlFromDataSet.ProductServiceReference;

namespace WP_GetXmlFromDataSet
{
  public partial class MainPage : PhoneApplicationPage
  {
    private const string KEY_NAME = "ProductData";

    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnGetXml_Click(object sender, RoutedEventArgs e)
    {
      GetXmlFromServer();
    }

    private void GetXmlFromServer()
    {
      ProductServiceClient client = new ProductServiceClient();

      client.GetXmlCompleted += new EventHandler<GetXmlCompletedEventArgs>(client_GetXmlCompleted);
      client.GetXmlAsync();
      client.CloseAsync();
    }

    void client_GetXmlCompleted(object sender, GetXmlCompletedEventArgs e)
    {
      // Store the XML data into Isolated Storage
      IsolatedStorageSettings.ApplicationSettings[KEY_NAME] = e.Result;
      btnRead.IsEnabled = true;
    }

    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      ReadProductXml();
    }

    private void ReadProductXml()
    {
      XElement xElem = null;

      if (IsolatedStorageSettings.ApplicationSettings.Contains(KEY_NAME))
      {
        xElem = XElement.Parse(IsolatedStorageSettings.ApplicationSettings[KEY_NAME].ToString());

        // Create a list of Product objects
        var products = from prod in xElem.Descendants("Product")
                       orderby prod.Attribute("ProductName").Value
                       select new Product
                       {
                         ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
                         ProductName = prod.Attribute("ProductName").Value,
                         IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
                         Price = Convert.ToDecimal(prod.Attribute("Price").Value)
                       };

        lstData.DataContext = products;
      }
    }
  }
}