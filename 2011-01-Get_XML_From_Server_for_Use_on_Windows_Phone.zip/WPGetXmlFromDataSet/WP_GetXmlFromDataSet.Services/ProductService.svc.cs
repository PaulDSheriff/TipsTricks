﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace WP_GetXmlFromDataSet.Services
{
  public class ProductService : IProductService
  {
    public string GetXml()
    {
      string ret = string.Empty;
      SqlDataAdapter da;
      DataSet ds = new DataSet();
      
      da = new SqlDataAdapter("SELECT * FROM Product",
        ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString);

      da.Fill(ds);

      foreach (DataColumn col in ds.Tables[0].Columns)
      {
        col.ColumnMapping = MappingType.Attribute;
      }

      ds.DataSetName = "Products";
      ds.Tables[0].TableName = "Product";
      ret = ds.GetXml();
      
      return ret;
    }
  }
}
