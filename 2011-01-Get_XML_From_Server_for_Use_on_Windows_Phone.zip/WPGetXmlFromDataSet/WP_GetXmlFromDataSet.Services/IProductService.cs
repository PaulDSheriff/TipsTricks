﻿using System.ServiceModel;

namespace WP_GetXmlFromDataSet.Services
{
  [ServiceContract]
  public interface IProductService
  {
    [OperationContract]
    string GetXml();
  }
}
