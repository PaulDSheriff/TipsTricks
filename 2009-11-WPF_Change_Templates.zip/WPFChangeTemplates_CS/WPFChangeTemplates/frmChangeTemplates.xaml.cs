﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFListBox
{
  /// <summary>
  /// Interaction logic for frmChangeTemplates.xaml
  /// </summary>
  public partial class frmChangeTemplates : Window
  {
    public frmChangeTemplates()
    {
      InitializeComponent();
    }

    private void btnMore_Click(object sender, RoutedEventArgs e)
    {
      DataTemplate tmpl;

      tmpl = (DataTemplate)this.FindResource("tmplMore");
      lstData.ItemTemplate = tmpl;
    }

    private void btnLess_Click(object sender, RoutedEventArgs e)
    {
      DataTemplate tmpl;

      tmpl = (DataTemplate)this.FindResource("tmplLess");
      lstData.ItemTemplate = tmpl;
    }
  }
}
