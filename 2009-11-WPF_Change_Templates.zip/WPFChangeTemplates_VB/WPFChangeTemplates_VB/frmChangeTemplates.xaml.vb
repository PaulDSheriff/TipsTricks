﻿Class frmChangeTemplates

  Private Sub btnMore_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnMore.Click
    Dim tmpl As DataTemplate

    tmpl = DirectCast(Me.FindResource("tmplMore"), DataTemplate)
    lstData.ItemTemplate = tmpl
  End Sub

  Private Sub btnLess_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnLess.Click
    Dim tmpl As DataTemplate

    tmpl = DirectCast(Me.FindResource("tmplLess"), DataTemplate)
    lstData.ItemTemplate = tmpl
  End Sub
End Class
