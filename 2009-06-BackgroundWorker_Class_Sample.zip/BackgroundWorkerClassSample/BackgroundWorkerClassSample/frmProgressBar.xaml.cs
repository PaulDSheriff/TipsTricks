﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.ComponentModel;  // For BackgroundWorker Class
using System.Threading;
using System.Windows.Media.Animation;

namespace WPFBusinessSamples
{
  /// <summary>
  /// Interaction logic for frmProgressBar.xaml
  /// </summary>
  public partial class frmProgressBar : Window
  {
    public frmProgressBar()
    {
      InitializeComponent();
    }

    #region Using BackgroundWorker Class
    BackgroundWorker mWorker = new BackgroundWorker();

    private void btnBackgroundWorker_Click(object sender, RoutedEventArgs e)
    {
      UsingBackgroundWorkerClass();
    }

    private void UsingBackgroundWorkerClass()
    {
      pbar.Value = 0;

      mWorker = new BackgroundWorker();
      mWorker.WorkerReportsProgress = true;
      mWorker.WorkerSupportsCancellation = true;

      mWorker.DoWork += new DoWorkEventHandler(mWorker_DoWork);
      mWorker.ProgressChanged += new ProgressChangedEventHandler(mWorker_ProgressChanged);
      mWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(mWorker_RunWorkerCompleted);
      
      // This will run the DoWork() event
      mWorker.RunWorkerAsync();
    }

    void mWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
    {
      pbar.Value = e.ProgressPercentage;
    }

    void mWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
    {
      if (e.Cancelled)
        MessageBox.Show("Cancelled by user");
      else
        MessageBox.Show("Complete");
    }

    void mWorker_DoWork(object sender, DoWorkEventArgs e)
    {
      // You can do any sort of lengthy work in here
      for (int index = 0; index < 100; index++)
      {
        mWorker.ReportProgress(index + 1);

        // Did the user cancel?
        if (mWorker.CancellationPending)
        {
          e.Cancel = true;
          return;
        }

        Thread.Sleep(20);
      }
      e.Result = 100;
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      mWorker.CancelAsync();
    }
    #endregion
  }
}
