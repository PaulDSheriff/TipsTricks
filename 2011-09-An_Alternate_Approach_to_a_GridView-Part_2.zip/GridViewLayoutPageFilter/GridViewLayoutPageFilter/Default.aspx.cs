﻿using System;
using System.Web.UI.WebControls;

namespace GridViewLayoutPageFilter
{
  public partial class Default : System.Web.UI.Page
  {
    protected void sortFields_SelectedIndexChanged(object sender, EventArgs e)
    {
      grdCust.Sort(sortFields.SelectedValue.ToString(), SortDirection.Ascending);      
    }
  }
}