﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Silverlight_Data
{
  public class Products : List<Product>
  {
    public Products()
    {
      BuildCollection();
    }

    public ObservableCollection<Product> DataCollection { get; set; }

    public ObservableCollection<Product> BuildCollection()
    {
      DataCollection = new ObservableCollection<Product>();

      DataCollection.Add(new Product(1, "Haystack Code Generator for .NET", "Product", 799));
      DataCollection.Add(new Product(2, "Microsoft VS.NET 2010", "Product", 2000));
      DataCollection.Add(new Product(3, "Microsoft Silverlight 4", "Product", 2000));
      DataCollection.Add(new Product(4, "Fundamentals of N-Tier eBook", "Book", 20));
      DataCollection.Add(new Product(5, "Fundamentals of ASP.NET Security eBook", "Book", 20));
      DataCollection.Add(new Product(6, "Fundamentals of SQL Server eBook", "Book", 20));
      DataCollection.Add(new Product(7, "Fundamentals of VB.NET eBook", "Book", 20));
      DataCollection.Add(new Product(8, "Fundamentals of .NET eBook", "Book", 20));
      DataCollection.Add(new Product(9, "Architecting ASP.NET eBook", "Book", 20));
      DataCollection.Add(new Product(10, "PDSA .NET Productivity Framework", "Product", 2500));

      return DataCollection;
    }
  }
}