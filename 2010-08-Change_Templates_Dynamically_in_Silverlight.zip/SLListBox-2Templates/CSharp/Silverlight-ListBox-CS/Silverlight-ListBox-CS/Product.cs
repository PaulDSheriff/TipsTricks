﻿using System;

namespace Silverlight_Data
{
  public class Product
  {
    #region Constructors

    public Product()
    {
    }

    public Product(int id, string name, string type, decimal price)
    {
      this.ProductId = id;
      this.ProductName = name;
      this.ProductType = type;
      this.Price = price;
    }
    #endregion

    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public string ProductType { get; set; }
    public decimal Price { get; set; }
  }
}