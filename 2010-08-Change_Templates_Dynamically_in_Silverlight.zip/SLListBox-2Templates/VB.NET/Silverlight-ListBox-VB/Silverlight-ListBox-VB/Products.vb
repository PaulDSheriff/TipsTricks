﻿Imports System.Collections.Generic
Imports System.Collections.ObjectModel

Public Class Products
  Inherits List(Of Product)

  Public Sub New()
    BuildCollection()
  End Sub

  Public Property DataCollection As ObservableCollection(Of Product)

  Public Function BuildCollection() As ObservableCollection(Of Product)
    DataCollection = New ObservableCollection(Of Product)

    DataCollection.Add(New Product(1, "Haystack Code Generator for .NET", "Product", 799))
    DataCollection.Add(New Product(2, "Microsoft VS.NET 2010", "Product", 2000))
    DataCollection.Add(New Product(3, "Microsoft Silverlight 4", "Product", 2000))
    DataCollection.Add(New Product(4, "Fundamentals of N-Tier eBook", "Book", 20))
    DataCollection.Add(New Product(5, "Fundamentals of ASP.NET Security eBook", "Book", 20))
    DataCollection.Add(New Product(6, "Fundamentals of SQL Server eBook", "Book", 20))
    DataCollection.Add(New Product(7, "Fundamentals of VB.NET eBook", "Book", 20))
    DataCollection.Add(New Product(8, "Fundamentals of .NET eBook", "Book", 20))
    DataCollection.Add(New Product(9, "Architecting ASP.NET eBook", "Book", 20))
    DataCollection.Add(New Product(10, "PDSA .NET Productivity Framework", "Product", 2500))

    Return DataCollection
  End Function
End Class
