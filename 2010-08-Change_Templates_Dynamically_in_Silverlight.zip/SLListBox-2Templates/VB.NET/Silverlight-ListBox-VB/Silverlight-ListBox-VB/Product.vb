﻿Public Class Product
#Region "Constructors"
  Public Sub New()

  End Sub

  Public Sub New(ByVal id As Integer, ByVal name As String, ByVal type As String, ByVal price As Decimal)
    Me.ProductId = id
    Me.ProductName = name
    Me.ProductType = type
    Me.Price = price
  End Sub
#End Region

  Public Property ProductId() As Integer
  Public Property ProductName() As String
  Public Property ProductType() As String
  Public Property Price() As Decimal
End Class