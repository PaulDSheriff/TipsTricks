﻿Partial Public Class MainPage
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub ChangeTemplate(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnMore.Click, btnLess.Click
    Dim dt As DataTemplate

    dt = CType(Me.Resources( _
          CType(sender, Button).Tag.ToString()),  _
            DataTemplate)

    lstData.ItemTemplate = dt
  End Sub
End Class