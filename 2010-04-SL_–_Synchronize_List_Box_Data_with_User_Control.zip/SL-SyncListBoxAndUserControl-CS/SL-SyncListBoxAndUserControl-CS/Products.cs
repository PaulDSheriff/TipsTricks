﻿using System.Collections.Generic;

namespace SL_SyncListBoxAndUserControl_CS
{
  public class Products : List<Product>
  {
    public Products()
    {
      this.Add(new Product(1, "Microsoft VS.NET 2008", 1000));
      this.Add(new Product(2, "Microsoft VS.NET 2010", 1000));
      this.Add(new Product(3, "Microsoft Silverlight 4", 1000));
      this.Add(new Product(4, "Fundamentals of N-Tier eBook", 20));
      this.Add(new Product(5, "ASP.NET Security eBook", 20));
    }
  }
}
