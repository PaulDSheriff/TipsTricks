﻿
namespace SL_SyncListBoxAndUserControl_CS
{
  public class Product
  {
    public Product(int productId, string productName, decimal price)
    {
      ProductId = productId;
      ProductName = productName;
      Price = price;
    }

    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public decimal Price { get; set; }
  }
}
