﻿using System.Windows.Controls;

namespace SL_SyncListBoxAndUserControl_CS
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }
  }
}
