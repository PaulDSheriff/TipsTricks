﻿Public Class Product
  Public Sub New(ByVal _productId As Integer, _
                 ByVal _productName As String, _
                 ByVal _price As Decimal)
    ProductId = _productId
    ProductName = _productName
    Price = _price
  End Sub

  Private mProductId As Integer
  Private mProductName As String
  Private mPrice As Decimal

  Public Property ProductId() As Integer
    Get
      Return mProductId
    End Get
    Set(ByVal value As Integer)
      mProductId = value
    End Set
  End Property

  Public Property ProductName() As String
    Get
      Return mProductName
    End Get
    Set(ByVal value As String)
      mProductName = value
    End Set
  End Property

  Public Property Price() As Decimal
    Get
      Return mPrice
    End Get
    Set(ByVal value As Decimal)
      mPrice = value
    End Set
  End Property
End Class
