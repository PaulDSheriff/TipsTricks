﻿Public Class Products
  Inherits List(Of Product)

  Public Sub New()
    Me.Add(New Product(1, "Microsoft VS.NET 2008", 1000))
    Me.Add(New Product(2, "Microsoft VS.NET 2010", 1000))
    Me.Add(New Product(3, "Microsoft Silverlight 4", 1000))
    Me.Add(New Product(4, "Fundamentals of N-Tier eBook", 20))
    Me.Add(New Product(5, "ASP.NET Security eBook", 20))
  End Sub
End Class
