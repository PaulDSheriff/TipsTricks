﻿using System.Windows;

namespace DataAccessMethods
{
	public partial class App : Application
	{
	}
}
