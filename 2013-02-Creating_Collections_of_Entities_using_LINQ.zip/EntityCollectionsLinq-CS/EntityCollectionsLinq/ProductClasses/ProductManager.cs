﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace DataAccessMethods
{
  public class ProductManager
  {
    #region GetProducts Method
    /// <summary>
    /// This method uses DataRow.Field&lt;T&gt;() method to retrieve data.
    /// The Field method works will nullable types.
    /// </summary>
    /// <returns>A List of Product objects</returns>
    public List<Product> GetProducts()
    {
      DataTable dt = new DataTable();
      SqlDataAdapter da = null;

      da = new SqlDataAdapter("SELECT * FROM Product",
                              AppSettings.Instance.ConnectString);

      da.Fill(dt);

      var query = (from dr in dt.AsEnumerable()
                   select new Product
                   {
                     ProductId = Convert.ToInt32(dr["ProductId"]),
                     ProductName = dr["ProductName"].ToString(),
                     IntroductionDate =
                       DataConvert.ConvertTo<DateTime>(dr["IntroductionDate"],
                         default(DateTime)),
                     Cost = DataConvert.ConvertTo<decimal>(
                       dr["Cost"], default(decimal)),
                     Price = DataConvert.ConvertTo<decimal>(
                       dr["Price"], default(decimal)),
                     IsDiscontinued = DataConvert.ConvertTo<bool>(
                       dr["IsDiscontinued"], default(bool))
                   });

      return query.ToList();
    }
    #endregion
  }
}
