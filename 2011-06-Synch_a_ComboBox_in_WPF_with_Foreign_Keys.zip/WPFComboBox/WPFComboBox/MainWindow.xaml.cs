﻿using System.Windows;

namespace WPFComboBox
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }
  }
}
