﻿using System.Collections.Generic;

namespace WPFComboBox
{
  public class Employee
  {
    public Employee(int id, string name, int empTypeId)
    {
      EmployeeId = id;
      Name = name;
      EmployeeTypeId = empTypeId;
    }

    public int EmployeeId { get; set; }
    public string Name { get; set; }
    public int EmployeeTypeId { get; set; }
  }

  public class Employees : List<Employee>
  {
  }
}
