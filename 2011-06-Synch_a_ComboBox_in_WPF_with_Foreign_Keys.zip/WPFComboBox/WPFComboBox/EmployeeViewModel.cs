﻿using System.Windows;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace WPFComboBox
{
  public class EmployeeViewModel : DependencyObject
  {
    public EmployeeViewModel()
    {
      LoadEmployees();
      LoadEmployeeTypes();
    }

    public EmployeeTypes EmployeeTypesCollection
    {
      get { return (EmployeeTypes)GetValue(EmployeeTypesCollectionProperty); }
      set { SetValue(EmployeeTypesCollectionProperty, value); }
    }

    public static readonly DependencyProperty EmployeeTypesCollectionProperty =
        DependencyProperty.Register("EmployeeTypesCollection", typeof(EmployeeTypes), typeof(EmployeeViewModel), null);

    public Employees EmployeeCollection
    {
      get { return (Employees)GetValue(EmployeeCollectionProperty); }
      set { SetValue(EmployeeCollectionProperty, value); }
    }

    public static readonly DependencyProperty EmployeeCollectionProperty =
        DependencyProperty.Register("EmployeeCollection", typeof(Employees), typeof(EmployeeViewModel), null);

    public void LoadEmployeeTypes()
    {
      EmployeeTypesCollection = new EmployeeTypes();
      EmployeeTypesCollection.Add(new EmployeeType(1, "Manager"));
      EmployeeTypesCollection.Add(new EmployeeType(2, "Project Manager"));
      EmployeeTypesCollection.Add(new EmployeeType(3, "Employee"));
    }

    public void LoadEmployees()
    {
      EmployeeCollection = new Employees();
      EmployeeCollection.Add(new Employee(1, "Michael Krasowski", 1));
      EmployeeCollection.Add(new Employee(2, "John Kuhn", 2));
      EmployeeCollection.Add(new Employee(3, "Jim Ruhl", 3));
      EmployeeCollection.Add(new Employee(4, "Russ Marzolf", 3));
      EmployeeCollection.Add(new Employee(4, "John Brongo", 3));
    }
  }
}
