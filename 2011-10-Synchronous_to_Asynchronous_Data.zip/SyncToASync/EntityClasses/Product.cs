﻿using System;
using System.Collections.Generic;

namespace EntityClasses
{
  public class Product
  {
    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public DateTime IntroductionDate { get; set; }
    public decimal Price { get; set; }
  }
}
