﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

using EntityClasses;

namespace DataService
{
  public class ProductService : IProductService
  {
    public List<Product> GetProducts()
    {
      List<Product> ret = new List<Product>();
      DataTable dt = new DataTable();
      SqlDataAdapter da;

      da = new SqlDataAdapter("SELECT * FROM Product",
        ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString);

      da.Fill(dt);

      foreach (DataRow item in dt.Rows)
      {
        Product prod = new Product();

        prod.ProductId = Convert.ToInt32(item["ProductId"]);
        prod.ProductName = Convert.ToString(item["ProductName"]);
        prod.IntroductionDate = Convert.ToDateTime(item["IntroductionDate"]);
        prod.Price = Convert.ToDecimal(item["Price"]);

        ret.Add(prod);
      }

      return ret;
    }
  }
}
