﻿CREATE TABLE Product
(
	ProductId int NOT NULL PRIMARY KEY NONCLUSTERED IDENTITY(1,1),
	ProductName varchar (50) NOT NULL ,
	IntroductionDate datetime NULL ,
	Cost money NULL ,
	Price money NULL ,
	IsDiscontinued tinyint NULL
)
GO

INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('PDSA .NET Productivity Framework','3/3/2002',10000,20000,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('Architecting ASP.NET Applications eBook','4/3/2002',10,19.95,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('Introduction to N-Tier Architecture eBook','6/4/2002',10,19.95,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('Security for ASP.NET Developers eBook','8/25/2002',10,19.95,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('PDSA IT Manager''s Toolkit','3/3/2002',2000,4000,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('VB.NET Fundamentals eBook','5/27/2004',10,19.95,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('Introduction to SQL Server 2000','1/11/2005',10,19.95,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('Using SharePoint 2003','5/2/2005',10,14.95,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('Developing SharePoint Web Parts','6/3/2005',10,19.95,0) 
INSERT INTO Product (ProductName,IntroductionDate,Cost,Price,IsDiscontinued) VALUES('PDSA Web Authoring System','4/12/2003',2500,5000,0) 
GO
