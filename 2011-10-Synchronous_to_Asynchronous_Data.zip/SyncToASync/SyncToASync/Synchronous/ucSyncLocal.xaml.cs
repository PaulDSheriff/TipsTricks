﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using EntityClasses;

namespace SyncToASync
{
  public partial class ucSyncLocal : UserControl
  {
    public ucSyncLocal()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      List<Product> coll;

      try
      {
        coll = GetProducts();

        lstData.DataContext = coll;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    public List<Product> GetProducts()
    {
      List<Product> ret = new List<Product>();
      DataTable dt = new DataTable();
      SqlDataAdapter da;

      da = new SqlDataAdapter("SELECT * FROM Product",
        ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString);

      da.Fill(dt);

      foreach (DataRow item in dt.Rows)
      {
        Product prod = new Product();

        prod.ProductId = Convert.ToInt32(item["ProductId"]);
        prod.ProductName = Convert.ToString(item["ProductName"]);
        prod.IntroductionDate = Convert.ToDateTime(item["IntroductionDate"]);
        prod.Price = Convert.ToDecimal(item["Price"]);

        ret.Add(prod);
      }

      return ret;
    }
  }
}
