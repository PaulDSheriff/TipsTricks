﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

using EntityClasses;
using SyncToASync.ProductSyncServiceReference;

namespace SyncToASync
{
  public partial class ucSyncService : UserControl
  {
    public ucSyncService()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      List<Product> ret;
      ProductServiceClient productService = new ProductServiceClient();

      try
      {
        ret = productService.GetProducts();
        productService.Close();

        lstData.DataContext = ret;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
