﻿To use this sample you will need to create a database named Sandbox
  Install the Product.sql in that database

Modify the connection strings in the App.Config and the Web.Config to point to your server and the Sandbox database

For ucSyncService.xaml file
  When you add the Service Reference, make sure you go into Advanced box and choose Collection Type: System.Collections.Generic.List instead of "System.Array".
  Also be sure to choose Reuse existing types; EntityClasses

