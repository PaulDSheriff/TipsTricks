﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using EntityClasses;
using SyncToASync.ProductAsyncServiceReference;

namespace SyncToASync
{
  public partial class ucAsync : UserControl
  {
    public ucAsync()
    {
      InitializeComponent();
    }

    ProductServiceClient _ProductService = new ProductServiceClient();

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        _ProductService.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
        _ProductService.GetProductsAsync();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      try
      {
        lstData.DataContext = e.Result;

        _ProductService.Close();
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
