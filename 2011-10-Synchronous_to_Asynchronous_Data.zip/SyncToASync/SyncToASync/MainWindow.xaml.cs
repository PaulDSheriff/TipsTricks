﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SyncToASync
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnSynchLocal_Click(object sender, RoutedEventArgs e)
    {
      ucSyncLocal uc = new ucSyncLocal();

      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }

    private void btnSynchService_Click(object sender, RoutedEventArgs e)
    {
      ucSyncService uc = new ucSyncService();

      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }

    private void btnAsynch_Click(object sender, RoutedEventArgs e)
    {
      ucAsync uc = new ucAsync();

      contentArea.Children.Clear();
      contentArea.Children.Add(uc);
    }
  }
}
