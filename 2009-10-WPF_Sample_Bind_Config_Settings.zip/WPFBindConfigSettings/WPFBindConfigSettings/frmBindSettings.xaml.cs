﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFBindConfigSettings
{
  /// <summary>
  /// Interaction logic for frmBindSettings.xaml
  /// </summary>
  public partial class frmBindSettings : Window
  {
    public frmBindSettings()
    {
      InitializeComponent();
    }

    private void btnRefresh_Click(object sender, RoutedEventArgs e)
    {
      //RefreshControls();
      RefreshINotify();
      //RefreshDataProvider();
    }

    private void RefreshINotify()
    {
      MySettings opts = (MySettings)((ObjectDataProvider)Application.Current.FindResource("odpSettings")).ObjectInstance;

      opts.Refresh();
    }

    private void RefreshControls()
    {
      MySettings opts = (MySettings)((ObjectDataProvider)Application.Current.FindResource("odpSettings")).ObjectInstance;

      opts.Refresh();

      txtDefaultState.GetBindingExpression(TextBox.TextProperty).UpdateTarget();
      chkIsActiveFlag.GetBindingExpression(CheckBox.IsCheckedProperty).UpdateTarget();
    }

    private void RefreshDataProvider()
    {
      ObjectDataProvider dp = (ObjectDataProvider)Application.Current.FindResource("odpSettings");
      MySettings opts = (MySettings)dp.ObjectInstance;

      opts.Refresh();

      dp.Refresh();
    }
  }
}
