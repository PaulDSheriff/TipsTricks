﻿using System;
using System.Configuration;
using System.ComponentModel;

namespace WPFBindConfigSettings
{
  public class MySettings : INotifyPropertyChanged
  {
    public MySettings()
    {
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected void RaisePropertyChanged(string propertyName)
    {
      var handler = PropertyChanged;
      if (handler != null)
      {
        handler(this, new PropertyChangedEventArgs(propertyName));
      }
    }        
    
    public string DefaultState
    {
      get
      {
        return ConfigurationManager.AppSettings["DefaultState"].ToString();
      }
    }

    public bool IsActiveFlag
    {
      get
      {
        return Convert.ToBoolean(ConfigurationManager.AppSettings["IsActiveFlag"]);
      }
    }

    public void Refresh()
    {
      ConfigurationManager.RefreshSection("appSettings");

      RaisePropertyChanged("DefaultState");
      RaisePropertyChanged("IsActiveFlag");
    }
  }
}