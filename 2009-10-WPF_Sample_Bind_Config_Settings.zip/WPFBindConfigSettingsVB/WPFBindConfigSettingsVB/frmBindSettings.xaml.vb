﻿Class frmBindSettings

  Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnRefresh.Click
    'RefreshControls()
    RefreshINotify()

    'RefreshDataProvider()
  End Sub

  Private Sub RefreshINotify()
    Dim opts As MySettings = DirectCast(DirectCast(Application.Current.FindResource("odpSettings"), ObjectDataProvider).ObjectInstance, MySettings)

    opts.Refresh()
  End Sub

  Private Sub RefreshControls()
    Dim opts As MySettings = DirectCast(DirectCast(Application.Current.FindResource("odpSettings"), ObjectDataProvider).ObjectInstance, MySettings)

    opts.Refresh()

    txtDefaultState.GetBindingExpression(TextBox.TextProperty).UpdateTarget()
    chkIsActiveFlag.GetBindingExpression(CheckBox.IsCheckedProperty).UpdateTarget()
  End Sub

  Private Sub RefreshDataProvider()
    Dim dp As ObjectDataProvider = DirectCast(Application.Current.FindResource("odpSettings"), ObjectDataProvider)
    Dim opts As MySettings = DirectCast(dp.ObjectInstance, MySettings)

    opts.Refresh()

    dp.Refresh()
  End Sub
End Class
