﻿Imports System.Configuration
Imports System.ComponentModel

Public Class MySettings
  Implements INotifyPropertyChanged

  Public Event PropertyChanged(ByVal sender As Object, ByVal e As System.ComponentModel.PropertyChangedEventArgs) Implements System.ComponentModel.INotifyPropertyChanged.PropertyChanged

  Protected Sub RaisePropertyChanged(ByVal propertyName As String)
    RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
  End Sub

  Public ReadOnly Property DefaultState() As String
    Get
      Return ConfigurationManager.AppSettings("DefaultState").ToString()
    End Get
  End Property

  Public ReadOnly Property IsActiveFlag() As Boolean
    Get
      Return Convert.ToBoolean(ConfigurationManager.AppSettings("IsActiveFlag"))
    End Get
  End Property

  Public Sub Refresh()
    ConfigurationManager.RefreshSection("appSettings")

    RaisePropertyChanged("DefaultState")
    RaisePropertyChanged("IsActiveFlag")
  End Sub
End Class
