﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace XamlLayout
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnGridMargins_Click(object sender, RoutedEventArgs e)
    {
      GridUsingMargins win = new GridUsingMargins();

      win.Show();
    }

    private void btnGridRowsColumns_Click(object sender, RoutedEventArgs e)
    {
      GridUsingRowsColumns win = new GridUsingRowsColumns();

      win.Show();
    }

    private void btnCanvas_Click(object sender, RoutedEventArgs e)
    {
      UsingCanvas win = new UsingCanvas();

      win.Show();
    }

    private void btnStackPanel_Click(object sender, RoutedEventArgs e)
    {
      UsingStackPanel win = new UsingStackPanel();

      win.Show();
    }
  }
}
