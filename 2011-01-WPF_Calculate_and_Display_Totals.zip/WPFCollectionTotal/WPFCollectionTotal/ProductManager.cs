﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace WPFCollectionTotal
{
  public class ProductManager : XamlBaseClass
  {
    #region PriceSum Property
    private decimal mPriceSum = 0;
    public decimal PriceSum
    {
      get { return mPriceSum; }
      set
      {
        if (mPriceSum != value)
        {
          mPriceSum = value;
          RaisePropertyChanged("PriceSum");
        }
      }
    }
    #endregion

    #region DataCollection Property
    private ObservableCollection<Product> mDataCollection = null;

    public ObservableCollection<Product> DataCollection
    {
      get { return mDataCollection; }
      set { 
        mDataCollection = value; 
      }
    }
    #endregion

    #region RecalcPriceSum Method
    public void RecalcPriceSum()
    {
      decimal total = 0;

      if (mDataCollection != null)
        foreach (Product item in mDataCollection)
          total += item.Price;

      PriceSum = total;
    }
    #endregion

    #region GetProducts Method
    public ObservableCollection<Product> GetProducts()
    {
      string fileName;

      fileName = WPFCommon.GetCurrentDirectory() +
        @"\Xml\Product.xml";

      if (File.Exists(fileName))
      {
        mDataCollection = GetProducts(fileName);

        // Hook CollectionChanged Event in case you 
        // add or delete from collection
        mDataCollection.CollectionChanged +=
          new NotifyCollectionChangedEventHandler(
            mDataCollection_CollectionChanged);
      }

      return mDataCollection;
    }

    void mDataCollection_CollectionChanged(object sender,
          NotifyCollectionChangedEventArgs e)
    {
      RecalcPriceSum();
    }

    public ObservableCollection<Product> GetProducts(string fileName)
    {
      XElement elem = XElement.Load(fileName);

      var items = from prod in elem.Descendants("Product")
                  select new Product
                  {
                    ProductId =
                        Convert.ToInt32(prod.Element("ProductId").Value),
                    ProductName = prod.Element("ProductName").Value,
                    IntroductionDate =
                        Convert.ToDateTime(prod.Element("IntroductionDate").Value),
                    Price = Convert.ToDecimal(prod.Element("Price").Value),
                    Cost = Convert.ToDecimal(prod.Element("Cost").Value),
                    IsDiscontinued =
                        Convert.ToBoolean(prod.Element("IsDiscontinued").Value)
                  };

      mDataCollection = new ObservableCollection<Product>(items);

      RecalcPriceSum();

      return mDataCollection;
    }
    #endregion
  }
}
