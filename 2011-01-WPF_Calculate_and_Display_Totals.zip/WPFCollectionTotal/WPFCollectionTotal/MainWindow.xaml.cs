﻿using System.Windows;
using System.Windows.Controls;

namespace WPFCollectionTotal
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void grdData_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
    {
      ProductManager prod;
      Product entity;

      if (grdData.Items.CurrentItem != null)
      {
        entity = (Product)grdData.Items.CurrentItem;
        grdData.CommitEdit();

        prod = (ProductManager)this.FindResource("productsObject");
        prod.RecalcPriceSum();
      }
    }

    //private void grdData_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
    //{
    //  ProductManager prod;
    //  Product entity;

    //  if (e.Column.Header.ToString() == "Price")
    //  {
    //    entity = (Product)grdData.Items.CurrentItem;
    //    entity.Price = 

    //    prod = (ProductManager)this.FindResource("productsObject");
    //    prod.RecalcPriceSum();
    //  }
    //}
  }
}
