using System;

namespace WPFCollectionTotal
{
  public partial class Product : XamlBaseClass
  {
    #region Private Variables
    private int mProductId = 0;
    private string mProductName = string.Empty;
    private DateTime mIntroductionDate = DateTime.Now;
    private decimal mPrice = 0;
    private bool mIsDiscontinued = false;
    private decimal mCost = 0;
    #endregion

    #region Public Properties
    public int ProductId
    {
      get { return mProductId; }
      set
      {
        if (mProductId != value)
        {
          mProductId = value;
          RaisePropertyChanged("ProductId");
        }
      }
    }

    public string ProductName
    {
      get { return mProductName; }
      set
      {
        if (mProductName != value)
        {
          mProductName = value;
          RaisePropertyChanged("ProductName");
        }
      }
    }

    public DateTime IntroductionDate
    {
      get { return mIntroductionDate; }
      set
      {
        if (mIntroductionDate != value)
        {
          mIntroductionDate = value;
          RaisePropertyChanged("IntroductionDate");
        }
      }
    }

    public decimal Price
    {
      get { return mPrice; }
      set
      {
        if (mPrice != value)
        {
          mPrice = value;
          RaisePropertyChanged("Price");
        }
      }
    }

    public bool IsDiscontinued
    {
      get { return mIsDiscontinued; }
      set
      {
        if (mIsDiscontinued != value)
        {
          mIsDiscontinued = value;
          RaisePropertyChanged("IsDiscontinued");
        }
      }
    }

    public decimal Cost
    {
      get { return mCost; }
      set
      {
        if (mCost != value)
        {
          mCost = value;
          RaisePropertyChanged("Cost");
        }
      }
    }
    #endregion
  }
}
