﻿namespace ADDomainListing
{
  public class ADDomain
  {
    public string Name { get; set; }
    public string Path { get; set; }
  }
}
