﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.DirectoryServices.ActiveDirectory;
using System.Windows;

namespace ADDomainListing
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtDomain.Text = Environment.UserDomainName;
      txtUserName.Text = Environment.UserName;
    }

    private void btnGetDomains_Click(object sender, RoutedEventArgs e)
    {
      lstDomains.DataContext = GetDomains(
        txtDomain.Text, txtUserName.Text,
        txtPassword.Password);
    }

    public List<ADDomain> GetDomains(string domainController,
      string userName, string password)
    {
      Domain domain = null;
      List<ADDomain> ret = new List<ADDomain>();
      Forest forest = null;

      try
      {
        // Connect to Domain
        domain = Domain.GetDomain(
          new DirectoryContext(
              DirectoryContextType.Domain,
              domainController,
              userName,
              password));

        // Get Current Domain Forest
        forest = domain.Forest;

        // Get all Domains in Forest
        foreach (Domain item in forest.Domains)
        {
          ADDomain ad = new ADDomain();

          // Create new class to get the Path
          ad.Name = item.Name;
          ad.Path = item.GetDirectoryEntry().Path;

          ret.Add(ad);
        }
      }
      catch (Exception ex)
      {
        Debug.WriteLine(ex.ToString());
      }

      return ret;
    }

  }
}
