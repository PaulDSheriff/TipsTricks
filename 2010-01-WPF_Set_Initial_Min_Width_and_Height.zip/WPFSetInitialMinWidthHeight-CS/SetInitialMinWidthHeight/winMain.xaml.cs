﻿using System;
using System.Windows;

namespace SetInitialMinWidthHeight
{
  /// <summary>
  /// Interaction logic for winMain.xaml
  /// </summary>
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    #region Dependency Properties
    protected static DependencyProperty InitialMinHeightProperty =
      DependencyProperty.Register(
        "InitialMinHeight", typeof(double), typeof(winMain));

    protected static DependencyProperty InitialMinWidthProperty =
      DependencyProperty.Register(
        "InitialMinWidth", typeof(double), typeof(winMain));
    #endregion

    #region Property
    protected double InitialMinHeight
    {
      get { return (Double)GetValue(InitialMinHeightProperty); }
      set { SetValue(InitialMinHeightProperty, value); }
    }

    protected double InitialMinWidth
    {
      get { return (Double)GetValue(InitialMinWidthProperty); }
      set { SetValue(InitialMinWidthProperty, value); }
    }
    #endregion

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Set dependency properties after form's width/height has been set initially
      InitialMinWidth = this.ActualWidth;
      InitialMinHeight = this.ActualHeight;
    }
  }
}
