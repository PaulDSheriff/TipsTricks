﻿Class winMain
#Region "Dependency Properties"
  Protected Shared InitialMinHeightProperty As DependencyProperty _
    = DependencyProperty.Register("InitialMinHeight", _
                                  GetType(Double), GetType(winMain))

  Protected Shared InitialMinWidthProperty As DependencyProperty _
    = DependencyProperty.Register("InitialMinWidth", _
                                  GetType(Double), GetType(winMain))
#End Region

#Region "Property"
  Protected Property InitialMinHeight() As Double
    Get
      Return DirectCast(GetValue(InitialMinHeightProperty), [Double])
    End Get
    Set(ByVal value As Double)
      SetValue(InitialMinHeightProperty, value)
    End Set
  End Property

  Protected Property InitialMinWidth() As Double
    Get
      Return DirectCast(GetValue(InitialMinWidthProperty), [Double])
    End Get
    Set(ByVal value As Double)
      SetValue(InitialMinWidthProperty, value)
    End Set
  End Property
#End Region

  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Set dependency properties after form's width/height has been set initially 
    InitialMinWidth = Me.ActualWidth
    InitialMinHeight = Me.ActualHeight
  End Sub
End Class
