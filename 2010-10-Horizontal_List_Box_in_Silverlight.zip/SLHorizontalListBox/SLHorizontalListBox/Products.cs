﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace SLHorizontalListBox
{
  public class Products : List<Product>
  {
    public Products()
    {
      BuildCollection();
    }

    public ObservableCollection<Product> DataCollection { get; set; }
    
    public ObservableCollection<Product> BuildCollection()
    {
      DataCollection = new ObservableCollection<Product>();

      DataCollection.Add(new Product("Haystack Code Generator for .NET", "Product", 799));
      DataCollection.Add(new Product("Fundamentals of N-Tier eBook", "Book", Convert.ToDecimal(19.95)));
      DataCollection.Add(new Product("Fundamentals of ASP.NET Security eBook", "Book", Convert.ToDecimal(19.95)));
      DataCollection.Add(new Product("Fundamentals of SQL Server eBook", "Book", Convert.ToDecimal(19.95)));
      DataCollection.Add(new Product("Fundamentals of VB.NET eBook", "Book", Convert.ToDecimal(19.95)));
      DataCollection.Add(new Product("Fundamentals of .NET eBook", "Book", Convert.ToDecimal(19.95)));
      DataCollection.Add(new Product("Architecting ASP.NET eBook", "Book", Convert.ToDecimal(19.95)));
      DataCollection.Add(new Product("PDSA .NET Productivity Framework", "Product", Convert.ToDecimal(2500)));

      return DataCollection;
    }
  }
}