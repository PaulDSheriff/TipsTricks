﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows;

namespace SLListBoxExpandingMenu
{
  /// <summary>
  /// Call this converter to change a True value to Visible and a False value to Collapsed
  /// </summary>
  public class BooleanToVisibilityConverter : IValueConverter
  {
    public object Convert(object value, Type targetType,
                          object parameter, CultureInfo culture)
    {
      if ((bool)value)
        return Visibility.Visible;
      else
        return Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType,
                              object parameter, CultureInfo culture)
    {
      throw new NotImplementedException("BooleanToVisibility ConvertBack Method Not Implemented");
    }
  }
}