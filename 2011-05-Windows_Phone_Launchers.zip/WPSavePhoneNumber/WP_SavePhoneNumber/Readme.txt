﻿This is an example of a "Launcher" as it just launches an application on the phone and passes some information into that app.
Your application will be tombstoned while the launcher is run
To return information, you need to declare the variable at the field level so it is recreated after the tombstoning