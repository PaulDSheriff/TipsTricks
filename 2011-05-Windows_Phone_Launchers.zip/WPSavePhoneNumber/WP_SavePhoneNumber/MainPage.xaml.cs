﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;

// Need to add this namespace for any launcher/chooser
using Microsoft.Phone.Tasks;

namespace WP_SavePhoneNumber
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Create Task here in order to fire the completed event
    // This is needed as your application will be tombstoned
    SavePhoneNumberTask _Task;

    // Constructor
    public MainPage()
    {
      InitializeComponent();

      // Need to create this here as your app will be tombstoned
      // Need to rehook the event for this Launcher app
      _Task = new SavePhoneNumberTask();
      _Task.Completed += new EventHandler<TaskEventArgs>(_Task_Completed);
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      // Pass phone number into contacts
      _Task.PhoneNumber = txtPhone.Text;
      // Display contact info app
      // This WILL tombstone your app
      _Task.Show();
    }

    void _Task_Completed(object sender, TaskEventArgs e)
    {
      if (e.TaskResult == TaskResult.OK)
        MessageBox.Show("Phone Number Saved");
    }
  }
}