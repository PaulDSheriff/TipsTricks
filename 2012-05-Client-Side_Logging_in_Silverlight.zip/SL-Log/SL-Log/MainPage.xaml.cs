﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using PDSA.Silverlight;

namespace SL_Log
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnLogInfo_Click(object sender, RoutedEventArgs e)
    {
      LogInfoSample();
    }

    private void LogInfoSample()
    {
      PDSALoggingManager.Instance.Log(txtDataToLog.Text);
      DisplayLog();
    }

    private void btnExtraValues_Click(object sender, RoutedEventArgs e)
    {
      Dictionary<string, string> extra = new Dictionary<string, string>();

      extra.Add("CustomerId", "1");
      extra.Add("StateCode", "CA");

      PDSALoggingManager.Instance.Log("Some data to log", extra);
      DisplayLog();
    }

    private void btnLogException_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        decimal ret = 10;

        ret = ret / 0;
      }
      catch (Exception ex)
      {
        PDSALoggingManager.Instance.LogException(ex);
        DisplayLog();
      }
    }

    private void btnLogExceptionExtraValues_Click(object sender, RoutedEventArgs e)
    {
      decimal ret = 10;

      try
      {
        ret = ret / 0;
      }
      catch (Exception ex)
      {
        Dictionary<string, string> extra = new Dictionary<string, string>();

        extra.Add("StackTraceFromException", ex.StackTrace);
        extra.Add("ret variable", ret.ToString());

        PDSALoggingManager.Instance.LogException(ex, extra);
        DisplayLog();
      }
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      PDSALoggingManager.Instance.DeleteLog();
      DisplayLog();
    }

    private void btnDisplayLog_Click(object sender, RoutedEventArgs e)
    {
      DisplayLog();
    }

    private void DisplayLog()
    {
      txtLog.Text = PDSALoggingManager.Instance.ReadLog();
    }

    private void btnCopyToClipboard_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        Clipboard.SetText(PDSALoggingManager.Instance.ReadLog());
      }
      catch
      {
        MessageBox.Show("Can't copy to the Clipboard.");
      }
    }

    private void btnSaveToFile_Click(object sender, RoutedEventArgs e)
    {
      SaveToFile(PDSALoggingManager.Instance.ReadLog());
    }

    private void SaveToFile(string contents)
    {
      SaveFileDialog sfd = null;

      try
      {
        sfd = new SaveFileDialog();
        sfd.DefaultExt = "txt";
        sfd.Filter = "Log Files (*.log)|*.log|All Files (*.*)|*.*";
        sfd.FilterIndex = 1;

        bool? result = sfd.ShowDialog();

        if (result.HasValue && result == true)
        {
          using (StreamWriter sw = new StreamWriter(sfd.OpenFile()))
          {
            sw.Write(contents);
            sw.Close();
          }
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }

    private void chkSystemInfo_Unchecked(object sender, RoutedEventArgs e)
    {
      PDSALoggingManager.Instance.LogSystemInfo = false;
    }

    private void chkSystemInfo_Checked(object sender, RoutedEventArgs e)
    {
      PDSALoggingManager.Instance.LogSystemInfo = true;
    }
  }
}
