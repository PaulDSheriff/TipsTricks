﻿The PDSA Silverlight Client-Side Logging Utility
----------------------------------------------------------
This logging utility is intended to be used by a Silverlight developer to track events and exceptions within the Silverlight application on the client-side, not the server side.

The class you call to log things is named PDSALoggingManager.
This class is located in the PDSA.Silverlight namespace.

Examples:
  private void LogData()
  {
    PDSALoggingManager.Log("Something to log");
  }

  private void LogExtraValues()
  {
    Dictionary<string, string> extra = new Dictionary<string, string>();

    extra.Add("CustomerId", "1");
    extra.Add("StateCode", "CA");

    PDSALoggingManager.Instance.Log("Some data to log", extra);
  }

The Log file is stored into an Isolated Storage file called "PDSALogging".
You can change this file name by setting the 'LogFileName' property of the PDSALoggingManager prior to calling the Log() method.

-----------------------------------------------
Properties of the PDSALoggingManager class
-----------------------------------------------
/// <summary>
/// Get/Set the current Log data in memory
/// </summary>
public StringBuilder TheLog { get; set; }
/// <summary>
/// Get/Set the calling class name
/// </summary>
public string CallingClassName { get; set; }
/// <summary>
/// Get/Set the log file name to use in isolated storage
/// </summary>
public string LogFileName { get; set; }
/// <summary>
/// Get/Set whether or not to log System information. The default is false
/// </summary>
public bool LogSystemInfo { get; set; }
/// <summary>
/// Get/Set the delimiter to use to separate items in the log. The default is Environment.Newline
/// </summary>
public string Delimiter { get; set; }
/// <summary>
/// A static/Shared instance of the PDSALoggingManager class.
/// </summary>
public static PDSALoggingManager Instance

-----------------------------------------------
Methods of the PDSALoggingManager class
-----------------------------------------------
/// <summary>
/// Logs an informational entry
/// </summary>
/// <param name="value">The value to log</param>
public void Log(string value)
/// <summary>
/// Logs an informational entry
/// </summary>
/// <param name="value">The value to log</param>
/// <param name="extraValues">A collection of extra values to write to the log</param>
public void Log(string value, Dictionary<string, string> extraValues)
/// <summary>
/// Logs an Exception entry
/// </summary>
/// <param name="value">The exception data to log</param>
public void LogException(Exception ex)
/// <summary>
/// Logs an Exception entry with extra values
/// </summary>
/// <param name="value">The exception data to log</param>
/// <param name="extraValues">A collection of extra values to write to the log</param>
public void LogException(Exception ex, Dictionary<string, string> extraValues)
/// <summary>
/// This is the method that all other "log" methods call to write to the log providers
/// </summary>
/// <param name="value">The value to Log</param>
/// <param name="logType">The type of log entry to create</param>
/// <param name="extraValues">A collection of extra values to write to the log</param>
public void Log(string value, string logType, Dictionary<string, string> extraValues)
/// <summary>
/// Gets the name of the class that called the Logging System.
/// </summary>
/// <returns>A class name</returns>
public string GetCallingClassName()
/// <summary>
/// Reads the current log data from memory if the 'TheLog' property has data. Otherwise the log data from the isolated storage file is read and returned.
/// </summary>
/// <returns>The log data</returns>
public string ReadLog()
/// <summary>
/// Delete the isolated storage file and clear the in-memory data in the 'TheLog' property
/// </summary>
public void DeleteLog()
/// <summary>
/// Reset all objects
/// </summary>
public void Reset()