﻿Class frmMain

  Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    DisplayLoginScreen()
  End Sub

  Private Sub DisplayLoginScreen()
    Dim frm As New frmLogin()

    frm.Owner = Me
    frm.ShowDialog()
    If frm.DialogResult.HasValue And frm.DialogResult.Value Then
      MessageBox.Show("User Logged In")
    Else
      Me.Close()
    End If
  End Sub
End Class
