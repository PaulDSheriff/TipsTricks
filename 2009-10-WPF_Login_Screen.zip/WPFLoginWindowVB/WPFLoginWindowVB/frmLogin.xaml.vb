﻿Partial Public Class frmLogin
  Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    DialogResult = False
    Me.Close()
  End Sub

  Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    DialogResult = True
    Me.Close()
  End Sub
End Class
