﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFLoginWindowCS
{
  /// <summary>
  /// Interaction logic for frmMain.xaml
  /// </summary>
  public partial class frmMain : Window
  {
    public frmMain()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DisplayLoginScreen();
    }

    private void DisplayLoginScreen()
    {
      frmLogin frm = new frmLogin();

      frm.Owner = this;
      frm.ShowDialog();
      if (frm.DialogResult.HasValue && frm.DialogResult.Value)
        MessageBox.Show("User Logged In");
      else
        this.Close();
    }
  }
}