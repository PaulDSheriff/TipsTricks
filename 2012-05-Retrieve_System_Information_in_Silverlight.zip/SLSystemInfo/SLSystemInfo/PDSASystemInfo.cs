using System;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Browser;

namespace PDSA.Silverlight
{
  /// <summary>
  /// This class will return the system information of the current running machine.
  /// </summary>
  public class PDSASystemInfo
  {
    #region Constructors
    /// <summary>
    /// Base constructor for the PDSASystemInfo class. Gets a reference to the main Silverlight Assembly.
    /// </summary>
    public PDSASystemInfo()
    {
      _CurrentAssm = Application.Current.GetType().Assembly;
    }
    #endregion

    #region Constants
    private const string _ERROR_MSG = "Can't Retrieve {0}";
    #endregion

    #region Private Variables
    private Assembly _CurrentAssm = null;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get the current URL
    /// </summary>
    public string CurrentUrl
    {
      get
      {
        try
        {
          return HtmlPage.Document.DocumentUri.ToString();
        }
        catch
        {
          return string.Format(_ERROR_MSG, "Current URL");
        }
      }
    }

    /// <summary>
    /// Gets the Operating System Version.
    /// </summary>
    public string OSVersion
    {
      get
      {
        try
        {
          return Environment.OSVersion.ToString();
        }
        catch
        {
          return string.Format(_ERROR_MSG, "Operating System Version");
        }
      }
    }

    /// <summary>
    /// Gets the Operating System Name.
    /// </summary>
    public string OSName
    {
      get
      {
        try
        {
          string ret = string.Empty;

          switch (Environment.OSVersion.Version.Major)
          {
            case 7:
              ret = "Windows 8";
              break;
            case 6:
              if (Environment.OSVersion.Version.Minor == 0)
                ret = "Windows Vista";
              else if (Environment.OSVersion.Version.Minor == 1)
                ret = "Windows 7";
              break;
            case 5:
              if (Environment.OSVersion.Version.Minor == 0)
                ret = "Windows 2000";
              else if (Environment.OSVersion.Version.Minor == 1)
                ret = "Windows XP";
              break;
            case 4:
              ret = "Windows NT";
              break;
            default:
              ret = "Windows 98";
              break;
          }

          return ret;
        }
        catch
        {
          return string.Format(_ERROR_MSG, "Operating System Name");
        }
      }
    }

    /// <summary>
    /// Gets the Company property from the Assembly
    /// </summary>
    public string Company
    {
      get
      {
        Type at = typeof(AssemblyCompanyAttribute);
        object[] c = _CurrentAssm.GetCustomAttributes(at, false);
        AssemblyCompanyAttribute att = ((AssemblyCompanyAttribute)(c[0]));
        return att.Company;
      }
    }

    /// <summary>
    /// Gets the Description property from the Assembly
    /// </summary>
    public string Description
    {
      get
      {
        Type at = typeof(AssemblyDescriptionAttribute);
        object[] c = _CurrentAssm.GetCustomAttributes(at, false);
        AssemblyDescriptionAttribute att = ((AssemblyDescriptionAttribute)(c[0]));
        return att.Description;
      }
    }

    /// <summary>
    /// Gets the Product property from the Assembly
    /// </summary>
    public string Product
    {
      get
      {
        Type at = typeof(AssemblyProductAttribute);
        object[] c = _CurrentAssm.GetCustomAttributes(at, false);
        AssemblyProductAttribute att = ((AssemblyProductAttribute)(c[0]));
        return att.Product;
      }
    }

    /// <summary>
    /// Gets the Title property from the Assembly
    /// </summary>
    public string Title
    {
      get
      {
        Type at = typeof(AssemblyTitleAttribute);
        object[] c = _CurrentAssm.GetCustomAttributes(at, false);
        AssemblyTitleAttribute att = ((AssemblyTitleAttribute)(c[0]));
        return att.Title;
      }
    }

    /// <summary>
    /// Gets the Copyright property from the Assembly
    /// </summary>
    public string Copyright
    {
      get
      {
        Type at = typeof(AssemblyCopyrightAttribute);
        object[] c = _CurrentAssm.GetCustomAttributes(at, false);
        AssemblyCopyrightAttribute att = ((AssemblyCopyrightAttribute)(c[0]));
        return att.Copyright;
      }
    }

    /// <summary>
    /// Gets the Version property from the Assembly
    /// </summary>
    public string Version
    {
      get
      {
        AssemblyName an = new AssemblyName(_CurrentAssm.FullName);
        return an.Version.ToString();
      }
    }

    /// <summary>
    /// Gets the Current Stack Trace.
    /// </summary>
    public string StackTrace
    {
      get
      {
        return GetStackTrace();
      }
    }

    /// <summary>
    /// Gets the current executing Assembly's Full Name.
    /// </summary>
    public string CurrentAssemblyName
    {
      get
      {
        try
        {
          return Assembly.GetExecutingAssembly().FullName;
        }
        catch
        {
          return string.Format(_ERROR_MSG, "Assembly Name");
        }
      }
    }

    /// <summary>
    /// Gets the Main Application's Assembly Full Name.
    /// </summary>
    public string MainAssemblyName
    {
      get
      {
        return _CurrentAssm.FullName;
      }
    }

    /// <summary>
    /// The Current Domain's Friendly Name.
    /// </summary>
    public string AppDomainName
    {
      get
      {
        try
        {
          return AppDomain.CurrentDomain.FriendlyName;
        }
        catch
        {
          return string.Format(_ERROR_MSG, "Application Domain Name");
        }
      }
    }

    /// <summary>
    /// Returns the current user language such as 'en-US' or 'es-MX' for the current thread of execution
    /// </summary>
    public string UserLanguage
    {
      get
      {
        return CultureInfo.CurrentCulture.Name;
      }
    }
    #endregion

    #region GetAllSystemInfo()
    /// <summary>
    /// Retrieves all system information properties from the PDSASystemInfo class and presents them in a string separated by the delimiter passed in.
    /// </summary>
    /// <param name="delimiter">The delimiter to separate all the properties</param>
    /// <returns>A string with all the system information.</returns>
    public string GetAllSystemInfo(string delimiter)
    {
      StringBuilder sb = new StringBuilder(1024);

      sb.Append("System Information" + delimiter);
      sb.Append("   DateTime=" + DateTime.Now.ToString() + delimiter);
      sb.Append("   Current URL=" + CurrentUrl + delimiter);
      sb.Append("   OSVersion=" + OSVersion + delimiter);
      sb.Append("   OSName=" + OSName + delimiter);
      sb.Append("   CurrentAssemblyName=" + CurrentAssemblyName + delimiter);
      sb.Append("   MainAssemblyName=" + MainAssemblyName + delimiter);
      sb.Append("   AppDomainName=" + AppDomainName + delimiter);
      sb.Append("   UserLanguage=" + UserLanguage + delimiter);
      sb.Append("   CompanyName=" + Company + delimiter);
      sb.Append("   ProductName=" + Product + delimiter);
      sb.Append("   Description=" + Description + delimiter);
      sb.Append("   Title=" + Title + delimiter);
      sb.Append("   Copyright=" + Copyright + delimiter);
      sb.Append("   ApplicationVersion=" + Version + delimiter);
      sb.Append("   Stack Trace=" + StackTrace);

      return sb.ToString();
    }
    #endregion

    #region GetStackTrace Method
    /// <summary>
    /// Gets the stack trace for the currently executing application.
    /// </summary>
    /// <returns>A Environment.NewLine delimited list of method names</returns>
    public string GetStackTrace()
    {
      StringBuilder sb = new StringBuilder(512);
      int loop = 0;
      string comma = string.Empty;
      string nameToMatch = MainAssemblyName;

      try
      {
        StackFrame sf = new StackFrame(loop);
        if (sf.GetMethod() != null)
          sb.Append("{");

        while (sf.GetMethod() != null)
        {
          // Get methods contained in the main assembly only
          if (sf.GetMethod().DeclaringType.Assembly.FullName.Equals(nameToMatch))
          {
            sb.Append(comma + sf.GetMethod().Name);
            comma = ",";
          }

          loop++;
          sf = new System.Diagnostics.StackFrame(loop);
        }
        if (sb.Length > 0)
          sb.Append("}");
      }
      catch
      {
        sb.AppendFormat(_ERROR_MSG, "Stack Trace");
      }

      return sb.ToString();
    }
    #endregion
  }
}
