﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;

// Added this for chooser task
using Microsoft.Phone.Tasks;

namespace WP_ChoosePhoneNumber
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Create Task here in order to fire the completed event
    // While some Choosers do not tombstone the app right away,
    // it is still a good idea to declare these here
    PhoneNumberChooserTask task = null;

    // Constructor
    public MainPage()
    {
      InitializeComponent();

      // Need to create this here as your app could be tombstoned
      // Need to rehook the event for this chooser app
      task = new PhoneNumberChooserTask();
      task.Completed += new EventHandler<PhoneNumberResult>(task_Completed);
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      // Show Phone Number Chooser
      // NOTE: This particular task does NOT necessarily tombstone your app.
      task.Show();
    }

    void task_Completed(object sender, PhoneNumberResult e)
    {
      // See if task completed
      if (e.TaskResult == TaskResult.OK)
        txtPhone.Text = e.PhoneNumber;  // Grab phone number
    }
  }
}