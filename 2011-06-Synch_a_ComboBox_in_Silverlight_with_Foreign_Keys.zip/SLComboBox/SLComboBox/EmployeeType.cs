﻿using System.Collections.Generic;

namespace SLComboBox
{
  public class EmployeeType
  {
    public EmployeeType(int id, string empType)
    {
      EmployeeTypeId = id;
      EmpType = empType;
    }

    public int EmployeeTypeId { get; set; }
    public string EmpType { get; set; }
  }

  public class EmployeeTypes : List<EmployeeType>
  {
  }
}
