﻿using System;
using System.Reflection;
using Vendor.Interfaces;

namespace XMLActivator
{
  /// <summary>
  /// This class matches the structure of the Vendor.xml file.
  /// This class also will create an instance of a Vendor class from the DLL listed in the XML file
  /// </summary>
  public class VendorClass
  {
    public int VendorId { get; set; }
    public string VendorName { get; set; }
    public string AssemblyName { get; set; }
    public string ClassName { get; set; }

    /// <summary>
    /// Create an instance of a Vendor class
    /// </summary>
    /// <returns>An instance of a Vendor class</returns>
    public IVendor Create()
    {
      Assembly assm;
      IVendor vendor = null;

      // Load Assembly File
      assm = Assembly.LoadFile(
        AppDomain.CurrentDomain.BaseDirectory + 
          AssemblyName + ".dll");

      // Create new instance of Class
      vendor = (IVendor)assm.CreateInstance(ClassName);

      // Set properties in the Provider class from the XML file 
      vendor.VendorId = VendorId;
      vendor.VendorName = VendorName;

      return vendor;
    }
  }
}
