﻿XML Activator Sample
---------------------------------------------
This sample shows how to create a list of classes that can be dynamically loaded from any assembly.
The list of classes (in this case, Vendor classes) is listed in an XML file
The XML file is loaded into memory using LINQ to XML
The XML file contains the name of the Assembly to load and the name of the class to create an instance of within that Assembly.


In order for this sample to work you must have the assemblies that you wish to load dynamically in the same folder as the main exe file.
In the Properties | Build tab of each of the "Vendor.xxx" DLLs, I set each DLL to be compiled into the XMLActivator\bin\Debug folder
