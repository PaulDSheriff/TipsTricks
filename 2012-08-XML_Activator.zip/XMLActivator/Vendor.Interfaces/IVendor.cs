﻿
namespace Vendor.Interfaces
{
  /// <summary>
  /// Each Vendor class must implement this interface
  /// </summary>
  public interface IVendor
  {
    int VendorId { get; set; }
    string VendorName { get; set; }
    string GetVendorInfo();
  }
}
