﻿
using Vendor.Interfaces;

namespace Vendor
{
  public class Microsoft : IVendor
  {
    public int VendorId { get; set; }
    public string VendorName { get; set; }

    public string GetVendorInfo()
    {
      return "Microsoft Corporation";
    }
  }
}
