﻿using System.Windows;
using Microsoft.Phone.Controls;

namespace WPReadTitle
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnReadTitle_Click(object sender, RoutedEventArgs e)
    {
      tbTitle.Text = WinPhoneCommon.GetApplicationTitle;
    }
  }
}