﻿
// Need to use both of these
using System.Linq;
using System.Xml.Linq;

namespace WPReadTitle
{
  /// <summary>
  /// This class contains common methods that any Windows Phone application can use
  /// </summary>
  public class WinPhoneCommon
  {
    /// <summary>
    /// Get the Application Title 
    /// from the WMAppManifest.xml file
    /// </summary>
    public static string GetApplicationTitle
    {
      get { return GetWinPhoneAttribute("Title"); }
    }

    /// <summary>
    /// Get the Application Description 
    /// from the WMAppManifest.xml file
    /// </summary>
    public static string GetApplicationDescription
    {
      get { return GetWinPhoneAttribute("Description"); }
    }

    /// <summary>
    /// Gets an attribute from the Windows Phone WMAppManifest.xml file
    /// To use this method, add a reference to the System.Xml.Linq DLL
    /// </summary>
    /// <param name="attributeName">The attribute to read</param>
    /// <returns>The Attribute's Value</returns>
    private static string GetWinPhoneAttribute(string attributeName)
    {
      string ret = string.Empty;

      try
      {
        XElement xe = XElement.Load("WMAppManifest.xml");
        var attr = (from manifest in xe.Descendants("App")
                    select manifest).SingleOrDefault();
        if (attr != null)
          ret = attr.Attribute(attributeName).Value;
      }
      catch
      {
        // Ignore errors in case this method is called 
        // from design time in VS.NET
      }

      return ret;
    }
  }
}
