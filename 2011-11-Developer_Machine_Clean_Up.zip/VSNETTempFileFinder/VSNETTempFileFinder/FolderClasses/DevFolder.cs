﻿using System;

namespace VSNETTempFileFinder
{
  class DevFolder
  {
    public DevFolder(string description)
    {
      Description = description;
    }

    public string Description { get; set; }
    public string FolderName { get; set; }
  }
}
