using System;

namespace VSNETTempFileFinder
{
  /// <summary>
  /// This class will return the system information of the current running machine.
  /// </summary>
  public class SystemInfo
  {
    /// <summary>
    /// Get whether or not the OS is 64 bit.
    /// </summary>
    public bool Is64bitOS
    {
      get { return (Environment.GetEnvironmentVariable("ProgramFiles(x86)") != null); }
    }


    /// <summary>
    /// Gets the Operating System Version. Same as Environment.OSVersion.ToString()
    /// </summary>
    public string OSVersion
    {
      get
      {
        try
        {
          return Environment.OSVersion.ToString();
        }
        catch
        {
          return "Environment.OSVersion not available";
        }
      }
    }

    /// <summary>
    /// Gets the Operating System Name.
    /// </summary>
    public string OSName
    {
      get
      {
        try
        {
          string strOS = string.Empty;

          switch (Environment.OSVersion.Version.Major)
          {
            case 6:
              if (Environment.OSVersion.Version.Minor == 0)
                strOS = "Windows Vista";
              else if (Environment.OSVersion.Version.Minor == 1)
                strOS = "Windows 7";

              break;
            case 5:
              if (Environment.OSVersion.Version.Minor == 0)
                strOS = "Windows 2000";
              else if (Environment.OSVersion.Version.Minor == 1)
                strOS = "Windows XP";

              break;
            case 4:
              strOS = "Windows NT";
              break;
            default:
              strOS = "Windows 98";
              break;
          }

          return strOS;
        }
        catch
        {
          return "OSName not available";
        }
      }
    }
  }
}
