﻿using System.Windows;

namespace VSNETTempFileFinder
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DevFolders folders = new DevFolders();
      SystemInfo si = new SystemInfo();

      lblOS.Content = si.OSName;
      lblVer.Content = si.OSVersion;
      if (si.Is64bitOS)
        lblSize.Content = "64 bit";
      else
        lblSize.Content = "32 bit";

      folders.LoadFolders();

      this.DataContext = folders;
    }
  }
}
