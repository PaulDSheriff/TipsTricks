﻿Imports System.Windows.Markup
Imports System.IO

Class frmLoadResources
  Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnLoad.Click
    DynamicLoadStyles()
  End Sub

  Private Sub DynamicLoadStyles()
    Dim fileName As String
    Dim dic As ResourceDictionary = Nothing

    fileName = Environment.CurrentDirectory & _
      "\Dictionaries\" & txtXamlName.Text

    If File.Exists(fileName) Then
      Using fs As FileStream = New FileStream(fileName, FileMode.Open)
        ' Read in ResourceDictionary File
        dic = CType(XamlReader.Load(fs), ResourceDictionary)
        ' Clear any previous dictionaries loaded
        Resources.MergedDictionaries.Clear()
        ' Add in newly loaded Resource Dictionary
        Resources.MergedDictionaries.Add(dic)
      End Using
    Else
      MessageBox.Show("File: " + fileName + _
                      " does not exist. Please re-enter.")
    End If
  End Sub
End Class
