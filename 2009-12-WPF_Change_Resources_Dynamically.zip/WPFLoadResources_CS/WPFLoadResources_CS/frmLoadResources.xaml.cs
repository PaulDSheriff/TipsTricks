﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Windows.Markup;
using System.IO;

namespace WPFLoadResources_CS
{
  /// <summary>
  /// Interaction logic for frmLoadResources.xaml
  /// </summary>
  public partial class frmLoadResources : Window
  {
    public frmLoadResources()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      DynamicLoadStyles();
    }

    private void DynamicLoadStyles()
    {
      string fileName;

      fileName = Environment.CurrentDirectory +
                   @"\Dictionaries\" + txtXamlName.Text;

      if (File.Exists(fileName))
      {
        using (FileStream fs = new FileStream(fileName, FileMode.Open))
        {
          // Read in ResourceDictionary File
          ResourceDictionary dic = (ResourceDictionary)XamlReader.Load(fs);
          // Clear any previous dictionaries loaded
          Resources.MergedDictionaries.Clear();
          // Add in newly loaded Resource Dictionary
          Resources.MergedDictionaries.Add(dic);
        }
      }
      else
        MessageBox.Show("File: " + txtXamlName.Text +
           " does not exist. Please re-enter the name.");
    }
  }
}
