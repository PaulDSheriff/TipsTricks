﻿using Microsoft.Phone.Controls;

namespace WPSortData
{
  public partial class MainPage : PhoneApplicationPage
  {
    public MainPage()
    {
      InitializeComponent();
    }
  }
}