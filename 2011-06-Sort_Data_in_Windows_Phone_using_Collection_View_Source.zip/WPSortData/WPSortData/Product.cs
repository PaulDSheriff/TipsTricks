﻿using System.Collections.Generic;

namespace WPSortData
{
  public class Product
  {
    public Product(int id, string name)
    {
      ProductId = id;
      ProductName = name;
    }

    public int ProductId { get; set; }
    public string ProductName { get; set; }
  }

  public class Products : List<Product>
  {
    public Products()
    {
      InitCollection();
    }

    public List<Product> DataCollection { get; set; }

    List<Product> InitCollection()
    {
      DataCollection = new List<Product>();

      DataCollection.Add(new Product(1, "PDSA Framework"));
      DataCollection.Add(new Product(2, "Haystack Code Generator"));
      DataCollection.Add(new Product(3, "Fundamentals of .NET eBook"));
      DataCollection.Add(new Product(4, "Introduction to Windows Phone Video"));
      DataCollection.Add(new Product(5, "MVVM Made Simple Video"));

      return DataCollection;
    }
  }
}
